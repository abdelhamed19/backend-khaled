<?php

namespace App\Rules;

use Closure;
use Illuminate\Contracts\Validation\ValidationRule;

class ImageRule implements ValidationRule
{
    public function __construct(public $size = 2048) {}

    public function validate(string $attribute, mixed $value, Closure $fail): void
    {
        if(!in_array($attribute ,self::files()))  $fail(trans('back.key_image_not_found'));

        if(!is_file($value)) $fail(trans('back.image-error'));

        [$type, $mime] = explode('/', $value->getMimeType());

        if(!in_array($mime, self::mimes())) $fail(trans('back.image-error'));

        if($value->getSize() < $this->size) $fail(trans('back.image-error'));
    }

    private static function mimes(): array
    {
        return ['png', 'jpg', 'webp', 'jpeg'];
    }
    private static function files(): array
    {
        return   ['image', 'photo', 'background', 'poster', 'logo', 'pdf', 'file'];
    }
}
