<?php

namespace App\Http\Middleware;

use App\Traits\ResponsesTrait;
use Closure;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Symfony\Component\HttpFoundation\Response;

class OTP
{
use ResponsesTrait;

    public function handle(Request $request, Closure $next): Response
    {
        $auth = Auth::guard('sanctum');


        if (!$auth->check()) {
            return $this->warning(trans('api.must-login'));
        }

        if (!$auth->user()->email_verified_at) {
            return $this->warning( trans('api.must-verify'));
        }

        return $next($request);
    }
}
