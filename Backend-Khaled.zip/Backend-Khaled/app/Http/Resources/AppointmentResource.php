<?php

namespace App\Http\Resources;

use Illuminate\Http\Request;
use Illuminate\Http\Resources\Json\JsonResource;

class AppointmentResource extends JsonResource
{
    /**
     * Transform the resource into an array.
     *
     * @return array<string, mixed>
     */
    public function toArray(Request $request): array
    {
        return [
            'appointment_id'      => $this->id,
            'patient'             => $this->patient_id,
//            'amount'  => $this->amount,
            'date'                => date('d-m-y',strtotime($this->date)),
            'time'                => $this->time,
        ];
    }
}
