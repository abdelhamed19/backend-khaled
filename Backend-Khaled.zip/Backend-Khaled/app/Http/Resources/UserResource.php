<?php

namespace App\Http\Resources;

use Illuminate\Http\Resources\Json\JsonResource;

class UserResource extends JsonResource
{
    public function toArray($request): array
    {

        return [
            'id' => (int)$this->id,
            'image' => (string)$this->image_path,
            'name' => (string)$this->full_name,
            'phone' => (int)$this->phone,
            'email' => (string)$this->email,

        ];
    }
}
