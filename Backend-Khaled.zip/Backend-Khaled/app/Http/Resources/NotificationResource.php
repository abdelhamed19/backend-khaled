<?php

namespace App\Http\Resources;

use Illuminate\Http\Resources\Json\JsonResource;

class NotificationResource extends JsonResource
{

    public function toArray($request)
    {
        return [
            'name'   => (string)$this->data['doctor']['name'],
            'date'   => $this->data['date'],
            'time'   => $this->data['time'],
            'status' => is_null($this->read_at)  ? 'not read' : 'read',
        ];
    }

}
