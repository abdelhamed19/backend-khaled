<?php

namespace App\Http\Resources;

use Illuminate\Http\Resources\Json\JsonResource;

class ChatDetailsResource extends JsonResource
{
    public function toArray($request): array
    {
        $auth_id = auth('sanctum')->id();
        $chat_member = ($this->receiver_id == $auth_id) ? $this->Sender : $this->Receiver;

        return [
            'chat_id' => (int)$this->id,
            'chat_check_if_i_sender' => ($this->sender_id == $auth_id),
            'chat_member' => UserResource::make($chat_member),
            'chat_status' => (string)$this->status,
        ];
    }
}
