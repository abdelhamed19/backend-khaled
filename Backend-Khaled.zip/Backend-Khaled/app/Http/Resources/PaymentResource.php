<?php

namespace App\Http\Resources;

use Illuminate\Http\Request;
use Illuminate\Http\Resources\Json\JsonResource;

class PaymentResource extends JsonResource
{
    /**
     * Transform the resource into an array.
     *
     * @return array<string, mixed>
     */
    public function toArray(Request $request): array
    {
        return [
            'transactionID' => $this->id,
            'appointmentTransaction' => $this->appointment_id,
            'patient'       => $this->user_id,
            'amount'        => $this->amount,
            'status'        => (int)$this->status
        ];
    }
}
