<?php

namespace App\Http\Resources;

use Illuminate\Http\Request;
use Illuminate\Http\Resources\Json\JsonResource;

class SettingResource extends JsonResource
{
    /**
     * Transform the resource into an array.
     *
     * @return array<string, mixed>
     */
    public function toArray(Request $request): array
    {
       return [
           'id'    => $this->id,
           'label' => $this->label,
           'key'   => $this->key,
           'value' => in_array($this->label, ['image', 'logo', 'photo']) ? $this->image_path : $this->value,
       ];
    }
}
