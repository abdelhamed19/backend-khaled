<?php

namespace App\Http\Resources;

use Illuminate\Http\Resources\Json\JsonResource;

class ChatMessagesResource extends JsonResource
{
    public function toArray($request): array
    {
        $if_mine = ($this->sender_id == auth('sanctum')->id());
        $chat = $this->Chat;
        $other_id = ($chat->sender_id == $this->sender_id) ? $chat->receiver_id : $chat->sender_id;

        return [
            'message_id' => (int)$this->id,
            'message_chat_id' => (int)$this->chat_id,
            'message_sender_id' => (int)$this->sender_id,
            'message_other_id' => (int)$other_id,
            'message_type' => (string)$this->message_type,
            'message_body' => (string)(($this->message_type == 'text') ? $this->message :
                (($this->message_type == 'image') ? $this->image_path : $this->voice_path)),
            'message_custom_date' => date('H:i A', strtotime($this->created_at)),
            'message_is_read' => (bool)$this->is_read,
            'message_if_mine' => $if_mine,
        ];
    }
}
