<?php

namespace App\Http\Resources;

use Illuminate\Http\Request;
use Illuminate\Http\Resources\Json\JsonResource;

class DoctorResource extends JsonResource
{
    /**
     * Transform the resource into an array.
     *
     * @return array<string, mixed>
     */
    public function toArray(Request $request): array
    {

        return [
            'id'            => $this->id,
            'name'          => $this->name,
            'image'         => $this->image_path,
            'cost'          => (double)$this->cost_examination,
            'details'       => $this->details,
            'desc'          => $this->desc,
            'working Hours' => WorkingResource::collection($this->appointments),
            'Date'          => DateResource::collection($this->appointments),

        ];


    }
}
