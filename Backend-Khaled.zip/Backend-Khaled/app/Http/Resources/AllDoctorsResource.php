<?php

namespace App\Http\Resources;

use Illuminate\Http\Request;
use Illuminate\Http\Resources\Json\JsonResource;

class AllDoctorsResource extends JsonResource
{
    /**
     * Transform the resource into an array.
     *
     * @return array<string, mixed>
     */
    public function toArray(Request $request): array
    {
            return [
                'id'       => $this->id,
                'name'     => $this->name,
                'desc'     => $this->desc,
                'image'    => $this->image_path,
                'rate'     => mt_rand(0,5),
                'fav'      => (bool)mt_rand(0,1),

            ];
    }
}
