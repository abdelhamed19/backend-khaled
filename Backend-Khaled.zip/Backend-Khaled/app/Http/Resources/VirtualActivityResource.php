<?php

namespace App\Http\Resources;

use Illuminate\Http\Request;
use Illuminate\Http\Resources\Json\JsonResource;

class VirtualActivityResource extends JsonResource
{
    /**
     * Transform the resource into an array.
     *
     * @return array<string, mixed>
     */
    public function toArray(Request $request): array
    {

        return [
            'id' => (int)$this->id,
            'user_id' => (int)$this->user_id,
            'game_id' => (int)$this->game_id,
            'if_level_open' => (bool)$this->if_level_open,
            'score' => (int)$this->score,
            'rate' => (int)$this->rate
        ];
    }
}
