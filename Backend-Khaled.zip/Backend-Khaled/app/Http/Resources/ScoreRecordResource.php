<?php

namespace App\Http\Resources;

use Illuminate\Http\Request;
use Illuminate\Http\Resources\Json\JsonResource;

class ScoreRecordResource extends JsonResource
{
    /**
     * Transform the resource into an array.
     *
     * @return array<string, mixed>
     */
    public function toArray(Request $request): array
    {

        return [
            'id' => (int)$this->id,
            'user_id' => (int)$this->user_id,
            'saturday_score' => (string)$this->saturday_score,
            'sunday_score' => (string)$this->sunday_score,
            'monday_score' => (string)$this->monday_score,
            'tuesday_score' => (string)$this->tuesday_score,
            'wednesday_score' => (string)$this->wednesday_score,
            'thursday_score' => (string)$this->thursday_score,
            'friday_score' => (string)$this->friday_score
        ];
    }
}
