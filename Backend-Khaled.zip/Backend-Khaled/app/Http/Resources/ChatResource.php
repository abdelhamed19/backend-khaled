<?php

namespace App\Http\Resources;

use Illuminate\Http\Resources\Json\JsonResource;
use Illuminate\Support\Str;

class ChatResource extends JsonResource
{
    public function toArray($request): array
    {
        $auth_id = auth('sanctum')->id();
        $chat_member = ($this->receiver_id == $auth_id) ? $this->Sender : $this->Receiver;

        $last_message = $this->LastMessage;
        $chat_last_message_text = ($last_message) ?
            (($last_message->message_type == 'text') ?
                $last_message->message :
                (($last_message->message_type == 'image') ? 'صورة' : 'مقطع صوتي')) :
            'محادثة جديدة';

        $chat_last_message_date = ($last_message) ?
            date('H:i A', strtotime($last_message->created_at)) :
            date('H:i A', strtotime($this->created_at));

        $UnreadMessagesNotMeCount = (int)$this->UnreadMessagesNotMe()->count();

        return [
            'chat_id' => (int)$this->id,
            'chat_member' => UserResource::make($chat_member),
            'chat_last_message_text' => Str::limit($chat_last_message_text),
            'chat_last_message_date' => $chat_last_message_date,
            'chat_unread_messages_count' => $UnreadMessagesNotMeCount,
        ];
    }
}
