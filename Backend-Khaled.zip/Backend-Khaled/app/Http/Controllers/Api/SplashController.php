<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Http\Resources\SplashResource;
use App\Models\Splash;
use App\Traits\ResponsesTrait;
use Illuminate\Http\Request;

class SplashController extends Controller
{
    use ResponsesTrait;

    public function index()
    {
        $splashs = Splash::get();
        return $this->success(trans('api.request-done-successfully'),SplashResource::collection($splashs));
    }
}
