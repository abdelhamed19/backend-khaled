<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Http\Resources\{AllDoctorsResource, DoctorResource};
use App\Models\Doctor;
use App\Models\User;
use App\Traits\ResponsesTrait;
use Illuminate\Http\Request;

class DoctorController extends Controller
{
    use ResponsesTrait;

    public function index(Request $request)
    {

        $doctors = Doctor::when($request->filled('search'), function ($query) use ($request) {
               return $query->where('name', 'Like', '%' . $request->search . '%');
            })->get();

        return $this->success(trans('api.request-done-successfully'), AllDoctorsResource::collection($doctors));
    }
    
     public function edit()

    {
           return $this->success(trans('api.request-done-successfully'),new DoctorResource(auth('sanctum')->user()));
    }

    public function show($id)
    {
        $doctor = Doctor::with('appointments')->find($id);

        if (!$doctor) return $this->warning(trans('api.not_found'));

        return $this->success(trans('api.request-done-successfully'), new DoctorResource($doctor));
    }


}
