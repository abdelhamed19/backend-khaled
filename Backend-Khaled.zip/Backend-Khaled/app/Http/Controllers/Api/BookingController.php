<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Notifications\PatientNotify;
use App\Http\Requests\Api\{AppointmentRequest, PaymentRequest};
use App\Http\Resources\{AppointmentResource, PaymentResource};
use App\Models\{Appointment, Doctor, Payment, User};
use App\Traits\ResponsesTrait;
use Illuminate\Support\Facades\DB;

class BookingController extends Controller
{
    use ResponsesTrait;

    public function appointment(AppointmentRequest $request)
    {
        $user = auth('sanctum')->user();
        $doctor = Doctor::find($request->doctor_id);

        if($user->user_type != 'patient') return $this->warning('The user not patient');

        if (!$doctor) return $this->warning(trans('The user not Doctor'));

        $appointment = Appointment::
            where(['doctor_id' => $request->doctor_id, 'time' => $request->time, 'date' => $request->date])
            ->where('status', '!=', 'finish')
            ->first();

        if ($appointment->count() === 0) return $this->warning('Appointment IS Not Available');

        try {

              $appointment->update(['patient_id' => $request->patient_id]);

            return $this->success(trans('api.request-done-successfully'), new AppointmentResource($appointment));

        } catch (\Exception $ex) {

            return $this->fails();
        }
    }

    public function payment(PaymentRequest $request)
    {
        $appointment = Appointment::find($request->appointment_id);
        $user = auth('sanctum')->user();

        if ($appointment->patient_id != $user->id) return $this->warning(trans('api.patient_not_match'));

        if (!$appointment) return $this->warning(trans('api.not_found'));

        try {
            DB::beginTransaction();

            $payment = Payment::create([
            'user_id'         => $user->id,
            'appointment_id'  => $appointment->id,
            'amount'          => $appointment->doctor->cost_examination,
            'card_name'       => $request->card_name,
            'card_number'     => $request->card_number,
            'cvv'             => $request->cvv,
            'expire_date'     => $request->expire_date
            ]);

            $appointment->update(['status' => 'paid']);

            $user  = User::find($appointment->patient_id);

            if($user->notification_status != 0)
            {
                $user->notify(new PatientNotify($appointment));
            }

            DB::commit();
            return $this->success('Paid successfully',[]);

        } catch (\Exception $ex) {

            dd($ex->getMessage());

            DB::rollBack();
            return $this->fails();
        }
    }

}
