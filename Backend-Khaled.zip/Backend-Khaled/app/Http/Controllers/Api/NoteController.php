<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Http\Requests\Api\NoteRequest;
use App\Http\Requests\EditNoteRequest;
use App\Http\Resources\NoteResource;
use App\Models\Note;
use App\Traits\ResponsesTrait;
use Illuminate\Http\Request;

class NoteController extends Controller
{
    use ResponsesTrait;

    public function index(Request $request)
    {
        $notes = Note::when($request->filled('search'), function ($q) use($request){
            $q->where('keyword','Like','%'.$request->search.'%');
        })->get();

        return $this->success(trans('api.request-done-successfully'),NoteResource::collection($notes));
    }

    public function store(NoteRequest $request)
    {


        try {
            $note = Note::create($request->validated());
            return $this->success(trans('api.request-done-successfully'),new NoteResource($note));
        }catch (\Exception $ex)
        {
            return $this->fails();
        }
    }

    public function update(EditNoteRequest $request,$id)
    {

        try {
            $note = Note::find($id);
            if (!$note) return $this->warning('Note Is Not Found');
            $note->update(['status' => $request->status]);

            return $this->success(trans('api.request-done-successfully'),new NoteResource($note));
        }catch (\Exception $ex)
        {
            return $this->fails();
        }
    }

}
