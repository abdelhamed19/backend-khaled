<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;

class AgoraController extends Controller
{
    public function getAgoraToken($id)
    {
        $time = strtotime(now()->addHour());
        $token = createAgoraToken($id, 0, $time);

        return Handle200($token);
    }
}
