<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Http\Requests\Api\VirtualActivityRequest;
use App\Http\Resources\VirtualActivityResource;
use App\Models\VirtualActivity;

class VirtualActivityController extends Controller
{
    public function index()
    {
        $user_id = auth('sanctum')->id();

        foreach (['1', '2', '3'] as $game) {
            $data = [];
            if ($game == '1') {
                $data = ['if_level_open' => true];
            }
            VirtualActivity::updateOrCreate(['user_id' => $user_id, 'game_id' => $game], $data);
        }

        $rows = VirtualActivity::where('user_id', $user_id)->orderBy('game_id')->get();

        return Handle200(VirtualActivityResource::collection($rows));
    }

    public function storeOrUpdate(VirtualActivityRequest $request)
    {
        $score = (int)$request->score;
        if ($score >= 60 && $score < 70) {
            $rate = 1;
        } elseif ($score >= 70 && $score < 80) {
            $rate = 2;
        } elseif ($score >= 80 && $score < 90) {
            $rate = 3;
        } elseif ($score >= 90 && $score <= 100) {
            $rate = 4;
        } else {
            $rate = 0;
        }

        $user_id = auth('sanctum')->id();
        $row = VirtualActivity::updateOrCreate(
            ['user_id' => $user_id, 'game_id' => $request->game_id],
            ['if_level_open' => true, 'score' => $score, 'rate' => $rate]
        )->refresh();

        if ($row->rate == 4 and $row->game_id < 3) {
            VirtualActivity::updateOrCreate([
                'user_id' => $user_id,
                'game_id' => ((int)$row->game_id) + 1,
            ], ['if_level_open' => true]);
        }

        return Handle200(VirtualActivityResource::make($row));
    }
}
