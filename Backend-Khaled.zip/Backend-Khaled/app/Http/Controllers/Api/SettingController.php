<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Http\Resources\SettingResource;
use App\Models\Setting;
use App\Traits\ResponsesTrait;
use Illuminate\Http\Request;

class SettingController extends Controller
{
    use ResponsesTrait;

    public function all()
    {
        $settings = Setting::get()->keyBy('key')->all();
        return $this->success(trans('api.request-done-successfully'), SettingResource::collection($settings));
    }

    public function show($id)
    {
        $setting = Setting::get()->keyBy('key')->all();
        return $this->success(trans('api.request-done-successfully'),new SettingResource($setting));
    }

}
