<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Http\Resources\AdviceResource;
use App\Models\Advice;
use App\Traits\ResponsesTrait;
use Illuminate\Http\Request;

class AdviceController extends Controller
{
    use ResponsesTrait;

    public function index()
    {
        return $this->success(trans('api.request-done-successfully'),[AdviceResource::collection(Advice::simplePaginate(5))]);
    }

    public function showAll($num=2)
    {
        $advices =Advice::orderByDesc('id')->paginate($num);
      return $this->success(trans('api.request-done-successfully'), [
              'advices' => AdviceResource::collection($advices),
              'pagination' => HandlePagination($advices)

      ]);
    }


}
