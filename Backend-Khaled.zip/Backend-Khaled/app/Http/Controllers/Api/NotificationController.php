<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Http\Resources\NotificationResource;
use App\Traits\ResponsesTrait;
use Illuminate\Http\Request;

class NotificationController extends Controller
{
    use ResponsesTrait;


    public function index()
    {
        $user = auth('sanctum')->user();
        $notifications = $user->unreadNotifications()->paginate(5);

        if ($user->user_type != 'patient') return $this->warning('The user is not Doctor');

        if (!$notifications) return $this->warning('Not found Notifications');

        return  $this->success(trans('api.request-done-successfully'),NotificationResource::collection($notifications));
    }

    public function read($notification_id)
    {
        $user = auth('sanctum')->user();
       $notification = $user->unreadNotifications()->where('id', $notification_id)->first();

        if ($notification) $notification->update(['read_at' => now()]);
        return  $this->success(trans('api.notify-read-success'),[]);
    }

    public function readAll()
    {
        $user = auth('sanctum')->user();
        $user->unreadNotifications->markAsRead();


        return  $this->success(trans('api.notify-read-all'),[]);
    }

    public function show($notification_id)
    {
        $user = auth('sanctum')->user();
        $notification = $user->notifications()->where('id', $notification_id)->first();

        if ($notification) $notification->update(['read_at' => now()]);
        return  $this->success(trans('api.request-done-successfully'),new NotificationResource($notification));
    }

    public function deleteAll()
    {
        $user = auth('sanctum')->user();
        $user->notifications()->delete();
        return  $this->success(trans('api.request-done-successfully'),$user);
    }


}
