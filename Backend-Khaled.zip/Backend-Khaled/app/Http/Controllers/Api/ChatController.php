<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Http\Resources\ChatDetailsResource;
use App\Http\Resources\ChatMessagesResource;
use App\Http\Resources\ChatResource;
use App\Http\Resources\UserResource;
use App\Models\Chat;
use App\Models\ChatMessage;
use App\Models\User;
use Exception;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Validator;

class ChatController extends Controller
{
    public function myChats(Request $request): JsonResponse
    {
        $auth_id = auth('sanctum')->id();
        $search = $request->search;

        $chats = Chat::query()
            ->selectRaw("chats.*, (SELECT MAX(created_at) from chat_messages WHERE chat_messages.chat_id=chats.id) as latest_message_on")
            ->AnyMember($auth_id)
            ->when($request->filled('search'), function ($query) use ($search) {
                $query->where(function ($query2) use ($search) {
                    $query2->whereHas('Sender', function ($query3) use ($search) {
                        return $query3->where('users.first_name', 'LIKE', "%$search%")->orWhere('users.last_name', 'LIKE', "%$search%");
                    })->orWhereHas('Receiver', function ($query3) use ($search) {
                        return $query3->where('users.first_name', 'LIKE', "%$search%")->orWhere('users.last_name', 'LIKE', "%$search%");
                    })->orWhereHas('LastMessage', function ($query3) use ($search) {
                        return $query3->where('chat_messages.message', 'LIKE', "%$search%");
                    });
                });
            })
            ->with(['Sender', 'Receiver', 'LastMessage'])
            ->orderByDesc('latest_message_on')->paginate();

        $otherSenderUsersIds = Chat::where('receiver_id', $auth_id)
            ->where('sender_status', 'on')->pluck('sender_id')->toArray();
        $otherReceiverUsersIds = Chat::where('sender_id', $auth_id)
            ->where('receiver_status', 'on')->pluck('receiver_id')->toArray();
        $usersActiveNow = User::whereIn('id', $otherSenderUsersIds)->orWhereIn('id', $otherReceiverUsersIds)->get();

        return Handle200([
            'users_active_now' => UserResource::collection($usersActiveNow),
            'data' => ChatResource::collection($chats),
            'pagination' => HandlePagination($chats)
        ]);
    }

    public function openChat(Request $request): JsonResponse
    {
        $rules = [];
        if ($request->filled('chat_id')) {
            $rules['chat_id'] = 'required|integer|exists:chats,id';
        } else {
            $rules['chat_type_id'] = 'required|integer|exists:users,id';
        }
        $validator = Validator::make($request->all(), $rules);
        if ($validator->fails()) return return_errors($validator);


        $auth_id = auth('sanctum')->id();
        $chat_type_id = $request->chat_type_id;

        if ($request->filled('chat_id')) {
            $my_chat = Chat::AnyMember($auth_id)->whereId($request->chat_id)->first();
        } else {
            $my_chat = Chat::where(function (Builder $query) use ($auth_id, $chat_type_id) {
                $query->where(function (Builder $query2) use ($auth_id, $chat_type_id) {
                    $query2->Me($auth_id)->Other($chat_type_id);
                })->orWhere(function (Builder $query3) use ($auth_id, $chat_type_id) {
                    $query3->Me($chat_type_id)->Other($auth_id);
                });
            })->first();
        }

        /* if chat found then return the data */
        if ($my_chat) {
            DB::beginTransaction();
            try {
                $my_chat->UnreadMessagesNotMe->each->update(['is_read' => 1]);

                $messages = ChatMessage::whereChatId($my_chat->id)->with('Chat')->orderByDesc('id')->paginate();

                /* handle chat status */
                $status_column = ($my_chat->sender_id == $auth_id) ? 'sender_status' : 'receiver_status';
                $my_chat->update([$status_column => 'on']);

                $data = [
                    'chat_details' => ChatDetailsResource::make($my_chat),
                    'data' => ChatMessagesResource::collection($messages),
                    'pagination' => HandlePagination($messages)
                ];

                DB::commit(); // all good
                return Handle200($data);
            } catch (Exception $e) {
                DB::rollback(); // something went wrong
                return Handle400('حدث خطأ ما ... برجاء المحاولة مرة أخرى');
            }
        }

        /* if chat not found and type is filled then create chat and return the data */
        if ($request->filled('chat_type_id')) {
            DB::beginTransaction();
            try {
                /* can't chat with yourself */
                if ($chat_type_id == $auth_id) {
                    return Handle400('لا يمكنك محادثة نفسك');
                }

                $data = [
                    'sender_id' => $auth_id,
                    'sender_status' => 'on',
                    'receiver_id' => $chat_type_id,
                    'receiver_status' => 'off'
                ];
                $new_chat = Chat::create($data);

                $messages = ChatMessage::whereChatId($new_chat->id)->with('Chat')->orderByDesc('id')->paginate();

                $data = [
                    'chat_details' => ChatDetailsResource::make($new_chat),
                    'data' => ChatMessagesResource::collection($messages),
                    'pagination' => HandlePagination($messages)
                ];

                DB::commit(); // all good
                return Handle200($data);
            } catch (Exception $e) {
                DB::rollback(); // something went wrong
                return Handle400('حدث خطأ ما ... برجاء المحاولة مرة أخرى');
            }
        }

        /* if chat not found and type is not filled then return 404 */
        return Handle404('لا يوجد محادثة بهذه البيانات');
    }

    public function sendMessage(Request $request): JsonResponse
    {
        $auth_id = auth('sanctum')->id();
        $rules = [
            'chat_id' => 'required|integer|exists:chats,id',
            'message_type' => 'required|string|in:text,image,voice',
        ];
        $rules['message'] = ($request->message_type == 'text') ? 'required|string|max:512' :
            (($request->message_type == 'image') ? 'required|mimes:jpg,jpeg,pjpeg,png,x-png,webp' : 'required|file');
        $validator = Validator::make($request->all(), $rules);
        if ($validator->fails()) return return_errors($validator);

        $chat = Chat::AnyMember($auth_id)->whereId($request->chat_id)->first();
        if (!$chat) return Handle404('لا يوجد محادثة بهذه البيانات');

        DB::beginTransaction();
        try {
            $data = [
                'chat_id' => $chat->id,
                'sender_id' => $auth_id,
                'message_type' => $request->message_type,
            ];
            if ($data['message_type'] == 'text') {
                $data['message'] = $request->message;
            } elseif ($data['message_type'] == 'image') {
                $data['message'] = ChatMessage::setImage($request->message);
            } else {
                $data['message'] = ChatMessage::setVoice($request->message);
            }
            $ChatMessage = ChatMessage::create($data);

            DB::commit(); // all good
            return Handle200(ChatMessagesResource::make($ChatMessage));
        } catch (\Exception $e) {
            DB::rollback(); // something went wrong
            return Handle400('حدث خطأ ما ... برجاء المحاولة مرة أخرى');
        }
    }

    public function closeChats(): JsonResponse
    {
        $user_id = auth('sanctum')->id();

        $sender_chats = Chat::select('id')->where(['sender_id' => $user_id, 'sender_status' => 'on'])->get();
        if ($sender_chats->count()) {
            $sender_chats->each->update(['sender_status' => 'off']);
        }

        $receiver_chats = Chat::select('id')->where(['receiver_id' => $user_id, 'receiver_status' => 'on'])->get();
        if ($receiver_chats->count()) {
            $receiver_chats->each->update(['receiver_status' => 'off']);
        }

        return Handle200('تم غلق المحادثات بنجاح');
    }
}
