<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Http\Requests\Api\editUserRequest;
use App\Http\Requests\Api\UserRequest;
use App\Http\Resources\AppointmentResource;
use App\Http\Resources\PatientResource;
use App\Http\Resources\PatientsResource;
use App\Http\Resources\UserResource;
use App\Models\Appointment;
use App\Models\Otp;
use App\Models\User;
use App\Traits\Responses;
use App\Traits\ResponsesTrait;
use Carbon\Carbon;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class UserController extends Controller
{
    use  responsesTrait;

    public function profile()

    {
           return $this->success(trans('api.request-done-successfully'),new UserResource(auth('sanctum')->user()));
    }
    
    public function edit()

    {
           return $this->success(trans('api.request-done-successfully'),new UserResource(auth('sanctum')->user()));
    }


    public function editProfile(editUserRequest $request)
    {
        try {

            $user = auth('sanctum')->user();
            $user->update( $request->validated());

           return $this->success(trans('api.update-success'),new UserResource($user));

        }catch (\Exception $ex)
        {
            return $this->fails();
        }
    }

    public function changeNotificationStatus()
    {
        $user = auth('sanctum')->user();

        $user->update(['notification_status'=>request('status')]);

        return $this->success(trans('api.request-done-successfully'), (int)$user->notification_status);
    }

    public function allPatient(Request $request)
    {
        $patients = User::whereHas('appointment')->whereUserType('patient')->when($request->filled('search'), function ($query) use ($request) {
            return $query->where('first_name', 'Like', '%' . $request->search . '%');
        })->get();

        return $this->success(trans('api.request-done-successfully'), PatientsResource::collection($patients));
    }

    public function showPatient($id)
    {
        $patient = User::with('notes')->whereUserType('patient')->find($id);

        return $this->success(trans('api.request-done-successfully'),new PatientResource($patient));
    }

    public function appointmentPatients(Request $request)
    {
        $patients = Appointment::whereHas('patient')->get();

        return $this->success(trans('api.request-done-successfully'), AppointmentResource::collection($patients));
    }


}
