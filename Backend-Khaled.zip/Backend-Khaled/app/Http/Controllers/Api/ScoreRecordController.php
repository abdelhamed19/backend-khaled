<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Http\Requests\Api\ScoreRecordRequest;
use App\Http\Resources\ScoreRecordResource;
use App\Models\ScoreRecord;

class ScoreRecordController extends Controller
{
    public function index()
    {
        $user_id = auth('sanctum')->id();
        $row = ScoreRecord::updateOrCreate(['user_id' => $user_id]);

        return Handle200(ScoreRecordResource::make($row->refresh()));
    }

    public function storeOrUpdate(ScoreRecordRequest $request)
    {
        $user_id = auth('sanctum')->id();
        $row = ScoreRecord::updateOrCreate(['user_id' => $user_id]);

        $row->update([$request->day_name . '_score' => $request->score]);

        return Handle200(ScoreRecordResource::make($row->refresh()));
    }
}
