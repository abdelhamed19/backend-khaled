<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Http\Requests\Api\QuestionRequest;
use App\Http\Resources\QuestionResources;
use App\Models\Question;
use App\Traits\ResponsesTrait;
use Illuminate\Support\Facades\DB;

class QuestionController extends Controller
{
    use ResponsesTrait;

    public function index()
    {
        return $this->success(trans('api.request-done-successfully'),[
            'task'  => 'The Task',
            'cover' => asset_url('questions/question.jpg'),
            'title' => 'The ADHD app',
            'desc'  => 'Lorem ipsum dolor sit amet, ut aliquam...consectetur adipiscing elit ut aliquam...Lorem ipsum dolor sit amet',
        ]);
    }


    public function show($id)
    {
        try {

            $question = Question::find($id);

            return $this->success(trans('api.request-done-successfully'),[
               'number'    =>'Question '. $id.'/'.Question::count(),
               'questions' => new QuestionResources($question),
                'cover'    => asset_url('questions/cover.jpg'),
            ]);

        }catch (\Exception $ex)
        {
            return $this->fails();
        }
    }

    public function answer(QuestionRequest $request,$id)
    {
        try {
            DB::beginTransaction();
            $user  = auth('sanctum')->user();

            $question = Question::find($id);

            if(!$question) return $this->warning('Question Is Not Found ',[]);

            DB::table('user_questions')->updateOrInsert([
                'question_id'   => $question->id,
                'user_id'       => $user->id,
            ],[
                'status_answer' => (int)$request->answer,
                'created_at'    => today(),
                'updated_at'    => today(),
            ]);

            DB::commit();
            return $this->success(trans('api.request-done-successfully'),[]);

        }catch (\Exception $ex)
        {
            DB::rollBack();
            return $this->fails();
        }
    }

    public function showResult()
    {
        $user  = auth('sanctum')->user();
        $result = $user->questions()
                ->where('status','complete')
                ->whereDate('user_questions.created_at' , now());

        return $this->success(trans('api.request-done-successfully'),[
            'date'  => date('M d/Y H:i A',strtotime(now())),
            'score' => (int)$result->sum('status_answer') .'/'. (int)$result->count(),
        ]);
    }
}
