<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Http\Requests\Api\FeedbackRequest;
use App\Http\Resources\{HomeResource, SettingResource, StaticPageResource};
use App\Models\{Feedback, Section, Setting, StaticPage};
use App\Traits\ResponsesTrait;

class HomeController extends Controller
{
    use ResponsesTrait;

    public function index()
    {
        $sections = Section::orderByDesc('id')->paginate(5);

        return $this->success(trans('api.request-done-successfully'), [
            'cover' => Setting::find(3)->value,
            'sections' => HomeResource::collection($sections)]);
    }

    public function more()
    {
        $settings = Setting::where('type', 'Others')->paginate(10);

        return $this->success(trans('api.request-done-successfully'), [
            'Support' => ['Get Help', 'See terms and privacy'],
            'Other apps from the developer' => SettingResource::collection($settings)
        ]);
    }

    public function showStaticPage($id)
    {
        $page = StaticPage::find($id);

        return $this->success(trans('api.request-done-successfully'), new StaticPageResource($page));
    }

    public function feed(FeedbackRequest $request)
    {
        try {
            Feedback::create($request->validated());
            return $this->success(trans('api.request-done-successfully'), []);
        } catch (\Exception $ex) {
            return $this->fails();
        }
    }


    public function letters()
    {
        return Handle200([
            [
                'image' => asset('storage/uploads/letters/1.jpeg'),
                'text' => 'أ'
            ],
            [
                'image' => asset('storage/uploads/letters/2.jpeg'),
                'text' => 'ب'
            ],
            [
                'image' => asset('storage/uploads/letters/3.jpeg'),
                'text' => 'ت'
            ],
            [
                'image' => asset('storage/uploads/letters/4.jpeg'),
                'text' => 'ث'
            ],
            [
                'image' => asset('storage/uploads/letters/5.jpeg'),
                'text' => 'ج'
            ],
            [
                'image' => asset('storage/uploads/letters/6.jpeg'),
                'text' => 'ح'
            ],
            [
                'image' => asset('storage/uploads/letters/7.jpeg'),
                'text' => 'خ'
            ],
            [
                'image' => asset('storage/uploads/letters/8.jpeg'),
                'text' => 'د'
            ],
            [
                'image' => asset('storage/uploads/letters/9.jpeg'),
                'text' => 'ذ'
            ],
            [
                'image' => asset('storage/uploads/letters/10.jpeg'),
                'text' => 'ر'
            ],
            [
                'image' => asset('storage/uploads/letters/11.jpeg'),
                'text' => 'ز'
            ],
            [
                'image' => asset('storage/uploads/letters/12.jpeg'),
                'text' => 'س'
            ],
            [
                'image' => asset('storage/uploads/letters/13.jpeg'),
                'text' => 'ش'
            ],
            [
                'image' => asset('storage/uploads/letters/14.jpeg'),
                'text' => 'ص'
            ],
            [
                'image' => asset('storage/uploads/letters/15.jpeg'),
                'text' => 'ض'
            ],
            [
                'image' => asset('storage/uploads/letters/16.jpeg'),
                'text' => 'ط'
            ],
            [
                'image' => asset('storage/uploads/letters/17.jpeg'),
                'text' => 'ظ'
            ],
            [
                'image' => asset('storage/uploads/letters/18.jpeg'),
                'text' => 'ع'
            ],
            [
                'image' => asset('storage/uploads/letters/19.jpeg'),
                'text' => 'غ'
            ],
            [
                'image' => asset('storage/uploads/letters/20.jpeg'),
                'text' => 'ف'
            ],
            [
                'image' => asset('storage/uploads/letters/21.jpeg'),
                'text' => 'ق'
            ],
            [
                'image' => asset('storage/uploads/letters/22.jpeg'),
                'text' => 'ك'
            ],
            [
                'image' => asset('storage/uploads/letters/23.jpeg'),
                'text' => 'ل'
            ],
            [
                'image' => asset('storage/uploads/letters/24.jpeg'),
                'text' => 'م'
            ],
            [
                'image' => asset('storage/uploads/letters/25.jpeg'),
                'text' => 'ن'
            ],
            [
                'image' => asset('storage/uploads/letters/26.jpeg'),
                'text' => 'ه‍'
            ],
            [
                'image' => asset('storage/uploads/letters/27.jpeg'),
                'text' => 'و'
            ],
            [
                'image' => asset('storage/uploads/letters/28.jpeg'),
                'text' => 'ي'
            ]
        ]);
    }
}
