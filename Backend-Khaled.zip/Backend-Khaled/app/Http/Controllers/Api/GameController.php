<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Http\Resources\GameResource;
use App\Models\Game;
use App\Traits\ResponsesTrait;
use Illuminate\Http\Request;

class GameController extends Controller
{
    use ResponsesTrait;

    public function index()
    {
//        return GameResource::collection(Game::paginate(6));

        return $this->success(trans('api.request-done-successfully'),[GameResource::collection(Game::paginate(6))]);
    }

}
