<?php

namespace App\Http\Controllers\Auth;

use App\Http\Controllers\Controller;
use App\Http\Requests\Api\RegisterRequest;
use App\Traits\FileTrait;
use App\Traits\ResponsesTrait;
use App\Models\{Doctor, Otp, User};
use Illuminate\Support\Facades\DB;

class RegisterController extends Controller
{

    use  ResponsesTrait,FileTrait;
    protected function register(RegisterRequest $request)
    {

        try{
            DB::beginTransaction();

            $user = User::create($request->validated());

            Otp::create(['user_id' => $user->id, 'code'  => 1111, 'expire' => now(),]);

            if ($user->user_type === 'doctor' && $request->hasFile('certificate'))
            {
                 $certificate =   $this->upload($request->certificate, 'user');
                 $user->update(['certificate' => $certificate]);
            }

            DB::commit();
            return $this->success('The user has successfully registered , then go to check code.',$user->email);

        }catch (\Exception $ex)
        {
            dd($ex);
            DB::rollBack();
            return $this->fails();
        }
    }

}
