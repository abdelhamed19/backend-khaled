<?php

namespace App\Http\Controllers\Auth;

use App\Facade\Support\ApiResponse;
use App\Facade\Support\Warning;
use App\Http\Controllers\Controller;
use App\Http\Requests\Api\CodeRequest;
use App\Http\Requests\Api\PasswordRequest;
use App\Http\Resources\UserResource;
use App\Models\Otp;
use App\Models\User;
use App\Traits\ResponsesTrait;
use App\Http\Requests\Api\EmailRequest;
use Illuminate\Support\Carbon;
use Illuminate\Support\Facades\Hash;


class ForgotPasswordController extends Controller
{

    use ResponsesTrait;

    public function recoverPassword(EmailRequest $request)
    {

        try {

            $user = User::where('email',$request->email)->orWhere('phone',$request->phone)->first();
            $user->update(['email_verified_at' => null, 'password' => Hash::make('@123@123')]);
            $otp = self::sendCode($user);

            if (is_null($otp)) return $this->warning('User Is Not Found.');

            return $this->success('sent code  Successfully ,than Go To Check code', $user->email);

        } catch (\Exception $e) {

            return $this->fails();
        }
    }

    public function checkCode(CodeRequest $request)
    {

        try {

            $user = User::where('email',$request->email)->orWhere('phone',$request->phone)->first();
            $otp   = Otp::where('user_id', $user->id)->first();

            if (Carbon::parse($otp->expire)->addMinute()->isPast()) return $this->warning('Time Is Expired.');

            $user->update(['email_verified_at' => date('y-m-d H:i:s')]);

            if(Hash::check('@123@123',$user->password)) return $this->success('The user has successfully inserted the code ,then Go To reset password',[]);

            return $this->success('The user has successfully inserted the code ,then Go To Login',[]);

        } catch (\Exception $ex) {

            return $this->fails();
        }
    }

    public function resendCode()
    {
        try {

            $user = User::where('email',request('email'))->first();

            $otp = self::sendCode($user);

            return $this->success(trans('api.resend-successfully') ,[]);

        } catch (\Exception $ex) {
            return $this->fails();
        }
    }

    private static function sendCode($user)
    {
        $code = 1111;

        $otp = Otp::where('user_id', $user->id)->first();

        $otp->update(['code' => $code, 'expire' => Carbon::now()->addMinute()]);

        return $code;

    }

}
