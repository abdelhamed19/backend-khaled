<?php

namespace App\Http\Controllers\Auth;

use App\Http\Controllers\Controller;
use App\Http\Requests\Api\PasswordRequest;
use App\Http\Resources\UserResource;
use App\Models\User;
use App\Providers\RouteServiceProvider;
use App\Traits\ResponsesTrait;
use Illuminate\Foundation\Auth\ResetsPasswords;
use Illuminate\Http\JsonResponse;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Hash;

class ResetPasswordController extends Controller
{

    use ResponsesTrait;
    public function resetPassword(PasswordRequest $request): JsonResponse
    {

        try {

            $user = User::where('email',$request->email)->first();

            if(is_null($user->email_verified_at)) return $this->warning('You must verify code first.');

            if (!$user) return $this->warning('User Is Not Found.');

            $user->update(['password' => Hash::make($request->password)]);

            return $this->success('Password Reset Successfully , then go to login', new UserResource($user));

        } catch (Exception $ex) {

            return $this->fails();
        }
    }

}
