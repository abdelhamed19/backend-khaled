<?php

namespace App\Http\Controllers\Auth;

use App\Http\Controllers\Controller;
use App\Http\Resources\UserResource;
use App\Models\User;
use App\Traits\Responses;
use App\Http\Requests\Api\LoginRequest;
use App\Traits\ResponsesTrait;
use Illuminate\Support\Facades\Auth;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;

class LoginController extends Controller
{
    use ResponsesTrait;

    public function login(LoginRequest $request)
    {

        try {

            $user = User::where('email', $request->email)->first();

            if(is_null($user->email_verified_at)) return $this->warning('You must verify code first.');

            if(!Hash::check($request->password, $user->password)) return $this->warning('Password Is Not Matched.');

            if(!Auth::attempt(['email' => $request->email, 'password' => $request->password]))  return $this->warning('Invalid login details');

            $token = $user->createToken('AuthToken')->plainTextToken;

            return $this->success(trans('api.login-done'),$token);

        }catch (\Exception $ex)
        {
            return $this->fails();
        }
    }

    public function logout()
    {
        auth('api')->user()->tokens()->delete();

        return $this->success(trans('api.logout-done'),[]);

    }
}
