<?php

namespace App\Http\Requests\Api;

use App\Http\Requests\REQUEST_API_PARENT;

class VirtualActivityRequest extends REQUEST_API_PARENT
{
    public function rules(): array
    {
        return [
            'game_id' => ['required', 'integer', 'in:1,2,3'],
            'score' => ['required', 'integer', 'min:0', 'max:100'],
        ];
    }
}
