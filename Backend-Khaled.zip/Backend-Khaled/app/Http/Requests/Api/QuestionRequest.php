<?php

namespace App\Http\Requests\Api;

use App\Http\Requests\REQUEST_API_PARENT;

class QuestionRequest extends REQUEST_API_PARENT
{

    public function rules(): array
    {
        return [
            'answer' => ['required','in:0,1'],
        ];
    }

}
