<?php

namespace App\Http\Requests\Api;

use App\Http\Requests\REQUEST_API_PARENT;
use Illuminate\Support\Str;

class NoteRequest extends REQUEST_API_PARENT
{

    public function rules(): array
    {
        return [
                'user_id'  => ['nullable'],
                'title'    => ['required', 'string', 'min:4'],
                'keyword'  => ['nullable', 'string'],
                'details'  => ['nullable'],
                'date'     => ['required','date_format:Y-m-d','after_or_equal:today'],
        ];
    }

    public function prepareForValidation()
    {
        $this->merge([
            'user_id' => auth('sanctum')->id(),
            'keyword' => Str::slug(request('title'))
        ]);
    }
}
