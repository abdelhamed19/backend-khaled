<?php

namespace App\Http\Requests\Api;

use App\Http\Requests\REQUEST_API_PARENT;

class AppointmentRequest extends REQUEST_API_PARENT
{

    public function rules(): array
    {

        return [
            'patient_id' => ['nullable'],
            'doctor_id'  => ['required','exists:doctors,id'],
            'date'       => ['required','date_format:Y-m-d','after_or_equal:today'],
            'time'       => ['required', 'date_format:H:i:s'],
        ];
    }

    public function prepareForValidation()
    {
          $this->merge([
             'patient_id' => auth('sanctum')->user()->id,
        ]);
    }

}
