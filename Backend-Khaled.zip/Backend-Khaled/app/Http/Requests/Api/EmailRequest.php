<?php

namespace App\Http\Requests\Api;

use App\Http\Requests\REQUEST_API_PARENT;

class EmailRequest extends REQUEST_API_PARENT
{
     public function rules(): array
    {
        return [
                    'email' => ['required', 'email' , 'exists:users,email']
        ];
    }
}
