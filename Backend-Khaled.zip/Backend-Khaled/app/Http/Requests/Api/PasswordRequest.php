<?php

namespace App\Http\Requests\Api;

use App\Http\Requests\REQUEST_API_PARENT;
use App\Rules\oldPassword;

class PasswordRequest extends REQUEST_API_PARENT
{

    public function rules(): array
    {

        return [
            'email' => ['required', 'email' , 'exists:users,email'],
            'password' => 'required|confirmed|min:8',

        ];
    }
}
