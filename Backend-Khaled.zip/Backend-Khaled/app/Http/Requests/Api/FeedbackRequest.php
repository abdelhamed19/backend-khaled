<?php

namespace App\Http\Requests\Api;

use App\Http\Requests\REQUEST_API_PARENT;
class FeedbackRequest extends REQUEST_API_PARENT
{

    public function rules(): array
    {
        return [
            'user_id'  => ['nullable'],
            'rate'     => ['required', 'in:1,2,3,4,5'],
            'message'  => ['nullable', 'string'],
        ];
    }

    public function prepareForValidation()
    {
        $this->merge([
            'user_id' => auth('sanctum')->id(),
        ]);
    }
}
