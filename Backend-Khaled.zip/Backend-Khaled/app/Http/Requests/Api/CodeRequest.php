<?php

namespace App\Http\Requests\Api;

use App\Http\Requests\REQUEST_API_PARENT;
use Illuminate\Foundation\Http\FormRequest;

class CodeRequest extends REQUEST_API_PARENT
{
    public function rules(): array
    {
        return [
            'code' => ['required', 'exists:otps,code'],
            'email' => ['required', 'email' , 'exists:users,email']

        ];
    }
}
