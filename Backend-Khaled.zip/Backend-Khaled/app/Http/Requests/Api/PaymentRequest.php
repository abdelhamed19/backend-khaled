<?php

namespace App\Http\Requests\Api;

use App\Http\Requests\REQUEST_API_PARENT;

class PaymentRequest extends REQUEST_API_PARENT
{

    public function rules(): array
    {

        return [
            'user_id'         => ['nullable'],
            'appointment_id'  => ['required','exists:appointments,id,status,new'],
//            'amount'          => ['required','numeric','doesnt_start_with:0','min_digits:1','exists:appointments,amount,id,'.request('appointment_id')],
            'card_name'       => ['required', 'string','max:255'],
            'card_number'     => ['required','numeric','min_digits:14','doesnt_start_with:0'],
            'cvv'             => ['required', 'numeric', 'digits_between:3,3'],
            'expire_date'     => ['required','date_format:Y-m-d','date_equals:today']
        ];
    }

    public function prepareForValidation()
    {
        $this->merge([
            'user_id' => auth('sanctum')->user()->id
        ]);
    }
}
