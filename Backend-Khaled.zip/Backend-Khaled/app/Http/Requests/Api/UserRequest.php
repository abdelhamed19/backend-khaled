<?php

namespace App\Http\Requests\Api;

use App\Http\Requests\REQUEST_API_PARENT;

class UserRequest extends REQUEST_API_PARENT
{
    public function rules(): array
    {
        return [
            'first_name' => ['required', 'string', 'min:3', 'max:40'],
            'last_name'  => ['required', 'string', 'min:3', 'max:40'],
            'email'      => ['required', 'string', 'email', 'max:255', 'unique:users,email'],
            'phone'      => ['required', 'numeric', 'digits_between:11,11','starts_with:0', 'unique:users,phone'],
            'id_number'  => ['required', 'numeric', 'digits_between:14,14','doesnt_start_with:0' ,'unique:users,id_number'],
            'password'   => ['required', 'min:8', 'confirmed'],
            'user_type'  => ['required','in:admin,patient,doctor'],
        ];
    }
}

?>
