<?php

namespace App\Http\Requests\Api;

use App\Http\Requests\REQUEST_API_PARENT;

class ScoreRecordRequest extends REQUEST_API_PARENT
{
    public function rules(): array
    {
        return [
            'day_name' => ['required', 'string', 'in:saturday,sunday,monday,tuesday,wednesday,thursday,friday'],
            'score' => ['required', 'numeric']
        ];
    }
}
