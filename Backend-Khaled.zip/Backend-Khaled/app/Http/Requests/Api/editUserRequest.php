<?php

namespace App\Http\Requests\Api;

use App\Http\Requests\REQUEST_API_PARENT;
use App\Rules\OldPassword;

class editUserRequest extends REQUEST_API_PARENT
{

    public function rules(): array
    {
        return [
            'email'      => ['nullable', 'string', 'email', 'max:255', 'unique:users,email,'.$this->user()->id.',id'],
            'phone'      => ['nullable', 'numeric', 'digits_between:11,11','starts_with:0', 'unique:users,phone,'.$this->user()->id.',id'],
            'password'   => ['nullable', 'min:8'],
        ];
    }
}
