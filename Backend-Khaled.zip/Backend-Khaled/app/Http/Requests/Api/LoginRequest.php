<?php

namespace App\Http\Requests\Api;

use App\Http\Requests\REQUEST_API_PARENT;
use App\Rules\OldPassword;
use Illuminate\Validation\Rule;

class LoginRequest extends REQUEST_API_PARENT
{

    public function rules(): array
    {

        return [
            'email'       => 'required|exists:users,email|email',
            'password'    => ['required','min:8'],
        ];
    }
}
