<?php

namespace App\Exceptions;

use App\Traits\ResponsesTrait;
use Illuminate\Auth\AuthenticationException;
use Illuminate\Database\Eloquent\ModelNotFoundException;
use Illuminate\Foundation\Exceptions\Handler as ExceptionHandler;
use Illuminate\Http\Exceptions\HttpResponseException;
use Illuminate\Http\Exceptions\ThrottleRequestsException;
use Illuminate\Http\JsonResponse;
use Illuminate\Validation\ValidationException;
use Symfony\Component\HttpKernel\Exception\NotFoundHttpException;
use Throwable;

class Handler extends ExceptionHandler
{
    use ResponsesTrait;
    /**
     * A list of exception types with their corresponding custom log levels.
     *
     * @var array<class-string<\Throwable>, \Psr\Log\LogLevel::*>
     */
    protected $levels = [
        //
    ];

    /**
     * A list of the exception types that are not reported.
     *
     * @var array<int, class-string<\Throwable>>
     */
    protected $dontReport = [
        //
    ];

    /**
     * A list of the inputs that are never flashed to the session on validation exceptions.
     *
     * @var array<int, string>
     */
    protected $dontFlash = [
        'current_password',
        'password',
        'password_confirmation',
    ];

    /**
     * Register the exception handling callbacks for the application.
     */
    public function register(): void
    {
        $this->reportable(function (Throwable $e) {
            //
        });
    }


    public function render($request, Throwable $e)
    {
        
        if ($request->is('api/*'))
        {

            if($e instanceof AuthenticationException) return $this->error('Not Auth.', $e->getMessage(),401);

            elseif($e instanceof ValidationException) return $this->error( 'Validation.', $e->getMessage(),  422);

            elseif($e instanceof HttpResponseException) return $this->error( 'response.', $e->getMessage(),  500);

            elseif($e instanceof NotFoundHttpException) return $this->error( 'Not Found',  $e);

            elseif ($e instanceof \ErrorException) return $this->error( null,  $e->getMessage());

            elseif($e instanceof \Error) return $this->error( null,  $e->getMessage());

            elseif($e instanceof ThrottleRequestsException) return $this->error( 'Too Many Attempts.', $e->getMessage(),  429);

            elseif($e instanceof ModelNotFoundException ) return $this->error( 'Not Found.', $e->getMessage() , 404);

            else return $this->error($e->getMessage());
        }

        return  parent::render($request, $e);

    }





}
