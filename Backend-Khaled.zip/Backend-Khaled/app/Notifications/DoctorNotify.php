<?php

namespace App\Notifications;

use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Notifications\Messages\MailMessage;
use Illuminate\Notifications\Notification;

class DoctorNotify extends Notification
{
    use Queueable;

    /**
     * Create a new notification instance.
     */
    private $appointment;

    public function __construct($appointment)
    {
        $this->appointment = $appointment;
    }

    public function via(object $notifiable): array
    {
        return ['database'];
    }


    public function toArray(object $notifiable): array
    {
        return [
            'title'     => 'New Reserve Number_' . $this->appointment->id,
            'patient'   => $this->appointment->patient->full_name,
            'date'      => date('Y-m-d',strtotime($this->appointment->date)),
        ];
    }
}
