<?php

use App\Helper\AgoraDynamicKey\RtcTokenBuilder;
use Illuminate\Http\JsonResponse;

function plural($singular): Stringable
{
    return str($singular)->plural();
}


function asset_url($url): string
{
    return app()->environment('production') ? url('/storage/app/public/uploads/' . $url) : url($url);
}

function HandlePagination($collection)
{
    return [
        'current_page' => (int)$collection->currentPage(),
        'last_page' => (int)$collection->lastPage(),
        'per_page' => (int)$collection->perPage(),
        'total' => (int)$collection->total(),
        'has_more_pages' => $collection->hasMorePages()
    ];
}


function Handle200($data)
{
    return response()->json([
        'status' => true,
        'code' => '200',
        'data' => $data
    ], 200);
}

function Handle400($message)
{
    return response()->json([
        'status' => false,
        'code' => '400',
        'message' => $message
    ], 400);
}

function Handle403($message)
{
    return response()->json([
        'status' => false,
        'code' => '403',
        'message' => $message
    ], 403);
}

function Handle404($message)
{
    return response()->json([
        'status' => false,
        'code' => '404',
        'message' => $message
    ], 404);
}

function return_errors($validator): JsonResponse
{
    $errors = $validator->errors();

    $error_data = '';

//    $error_data = [];

    foreach ($errors->all() as $error) {
//        array_push($error_data, $error);
        $error_data .= $error . " \n ";
    }

//    $data = rtrim($error_data, "\\n");

    return response()->json(['status' => false, 'code' => '400', 'message' => $error_data], 400);
}

function createAgoraToken($channel_name, $uid, $privilegeExpiredTs)
{
    $appID = config('graduation.agora.app_id');
    $appCertificate = config('graduation.agora.certificate');
    $role = RtcTokenBuilder::RoleAttendee;
    return RtcTokenBuilder::buildTokenWithUserAccount(
        $appID,
        $appCertificate,
        (string)$channel_name,
        (int)$uid,
        $role,
        $privilegeExpiredTs
    );
}

function StoreMedia($media, $path): string
{
    $media_name = date('YmdHis') . rand(0000, 9999) . '.' . $media->getClientOriginalExtension();

    $destinationPath = public_path($path);

    $media->move($destinationPath, $media_name);

    return $media_name;
}

function HandleMedia_($mediaPath, $mediaName)
{
    if ($mediaName and file_exists($mediaPath . $mediaName)) {
        return url($mediaPath . $mediaName);
    }

    return public_path('/storage/uploads/no_image.png');
}

?>
