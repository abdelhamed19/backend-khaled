<?php

namespace App\Providers;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Pagination\Paginator;
use Illuminate\Support\{Facades\URL, ServiceProvider, Facades\Schema};
use Laravel\Sanctum\{PersonalAccessToken, Sanctum};

class AppServiceProvider extends ServiceProvider
{
    /**
     * Register any application services.
     */
    public function register(): void
    {
        //
    }

    /**
     * Bootstrap any application services.
     */
    public function boot(): void
    {

        Paginator::useBootstrap();

        if(env('APP_ENV') !== 'local') {
            URL::forceScheme('https');
        }

        Schema::defaultStringLength(191);
        Schema::enableForeignKeyConstraints();

        Sanctum::usePersonalAccessTokenModel(PersonalAccessToken::class);

        Model::preventLazyLoading(false);
        Model::preventLazyLoading(!app()->isProduction());
        Model::unguard();

    }
}

?>
