<?php
namespace App\Traits;

use Illuminate\Http\JsonResponse;

trait ResponsesTrait
{

    public function success($message, $data): JsonResponse
    {
        return self::responseJsonMessage(true,$message,$data,200);

    }

    public  function warning($message, $data=[]): JsonResponse
    {
        return self::responseJsonMessage(false,$message,$data,401);
    }

    public  function error($message, $data = null, $code = 500): JsonResponse
    {
        return self::responseJsonMessage(false,$message,$data,$code);
    }

    public static function fails($data = []): JsonResponse
    {
        return self::responseJsonMessage(false,trans('api.errorTech'),$data,500);
    }


    private static function responseJsonMessage($status = true, string $message,  $data ,$code = 200): JsonResponse
    {
        return response()->json(['status' => $status, 'message' => $message,'data' => $data],$code);
    }

    private static function handleMessage($e): string
    {
        return $e->getMessage() . ' in code ' . $e->getCode() . ' at line ' . $e->getLine();
    }

}

?>
