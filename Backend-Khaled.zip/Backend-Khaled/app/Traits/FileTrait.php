<?php
namespace App\Traits;

use Illuminate\Support\Facades\File;
use Illuminate\Support\Facades\Storage;

trait FileTrait
{

    public static function upload($file, $folder): string
    {

        $fileName = plural($folder)."_".$file->getClientoriginalName();

        $file->move(self::dir($folder), $fileName);

        return $fileName;
    }

    public function delete($folder, $file_name): string
    {
        return File::exists($folder . '/' . $file_name) ? storage_unlink($folder, $file_name) : __('api.not_found');
    }

    public function update($folder, $file_name, $new,$first,$last)
    {
        $old = $folder . '/' . $file_name;
        $name = $first.$last;

        if (file_exists($old))
        {
            if (is_null(request('image'))) return self::generateImage($name);
            if (is_file(request('image'))) {
                    storage_unlink($old);
                return self::upload($new, $folder);
            }
        }

    }

    private static function dir($model): string
    {
        $path = storage_path('uploads/' . plural($model));

//        !is_dir($path) or mkdir($path, 0777, true);

        return $path;
    }

    protected static function generateImage($name): string
    {
        $image = '';

        $arr_photo = explode(' ', $name);

        foreach ($arr_photo as $photo) {
            $image .= ucfirst(mb_substr($name, 0, 2, 'UTF-8'));
        }

        return $image;
    }

}

?>
