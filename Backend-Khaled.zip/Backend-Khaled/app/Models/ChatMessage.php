<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class ChatMessage extends Model
{
    protected $guarded = ['id'];
    protected $appends = ['image_path', 'voice_path'];


    public function Chat()
    {
        return $this->belongsTo(Chat::class, 'chat_id')->withDefault();
    }

    public function Sender()
    {
        return $this->belongsTo(User::class, 'sender_id')->withDefault();
    }


    public function scopeText($query)
    {
        return $query->where('message_type', 'text');
    }

    public function scopeImage($query)
    {
        return $query->where('message_type', 'image');
    }

    public function scopeVoice($query)
    {
        return $query->where('message_type', 'voice');
    }

    public function scopeUnRead($query)
    {
        return $query->where('is_read', 0);
    }

    public function scopeRead($query)
    {
        return $query->where('is_read', 1);
    }


    public static function setImage($value)
    {
        set_time_limit(0);
        return StoreMedia($value, '/storage/uploads/chats');
    }

    public function getImagePathAttribute()
    {
        return HandleMedia_('storage/uploads/chats/', $this->message);
    }

    public static function setVoice($value)
    {
        set_time_limit(0);
        return StoreMedia($value, '/storage/uploads/chats');
    }

    public function getVoicePathAttribute()
    {
        return HandleMedia_('storage/uploads/chats/', $this->message);
    }
}
