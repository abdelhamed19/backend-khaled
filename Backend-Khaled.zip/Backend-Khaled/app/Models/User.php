<?php

namespace App\Models;

// use Illuminate\Contracts\Auth\MustVerifyEmail;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Database\Eloquent\Casts\Attribute;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Relations\BelongsToMany;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Database\Eloquent\Relations\HasOne;
use Illuminate\Foundation\Auth\User as Authenticatable;
use Illuminate\Notifications\Notifiable;
use Laravel\Sanctum\HasApiTokens;
use Laravel\Sanctum\PersonalAccessToken;

class User extends Authenticatable
{
    use HasApiTokens, HasFactory, Notifiable;

    protected $fillable = ['first_name', 'last_name', 'email', 'password', 'user_type', 'phone', 'id_number','notification_status','image'];

    protected $casts = ['created_at' => 'timestamp', 'password' => 'hashed'];

    protected $hidden = ['password', 'remember_token'];

    protected $appends = ['image_path', 'full_name', 'token'];

    protected function Token(): Attribute
    {
        return Attribute::make(
            get: fn() => $this->getToken()->id ."|". $this->getToken()->token,
        );
    }

    private  function getToken()
    {
       return PersonalAccessToken::where('tokenable_id',$this->id)->first();
    }

    protected function ImagePath(): Attribute
    {
        return Attribute::make(
            get: fn() => asset_url('users/' . $this->image),
        );
    }

    protected function FullName(): Attribute
    {
        return Attribute::make(
            get: fn() => $this->first_name . " " . $this->last_name,
        );
    }


    public function codeOtp(): HasOne
    {
        return $this->hasOne(Otp::class);
    }

    public function appointment(): HasOne
    {
        return $this->hasOne(Appointment::class,'patient_id');
    }


    public function payment(): HasOne
    {
        return $this->hasOne(Payment::class);
    }

    public function notes(): HasMany
    {
        return $this->hasMany(Note::class);
    }

    public function feeds(): HasMany
    {
        return $this->hasMany(Feedback::class);
    }

    public function questions(): BelongsToMany
    {
        return $this->belongsToMany(Question::class,'user_questions','user_id','question_id')
                ->withPivot(['status_answer','status'])
                ->withTimestamps();
    }

}
