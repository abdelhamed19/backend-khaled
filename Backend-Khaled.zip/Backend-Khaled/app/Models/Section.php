<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Casts\Attribute;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Section extends Model
{
    use HasFactory;

    protected $fillable = ['title', 'subtitle','image'];

    protected $appends = ['image_path'];

    protected function ImagePath(): Attribute
    {
        return Attribute::make(
            get: fn() => asset_url('sections/' . $this->image),
        );
    }
}
