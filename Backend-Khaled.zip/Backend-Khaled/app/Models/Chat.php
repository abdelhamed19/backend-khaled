<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Builder;
use Illuminate\Database\Eloquent\Model;

class Chat extends Model
{
    protected $guarded = ['id'];


    public function Sender()
    {
        return $this->belongsTo(User::class, 'sender_id')->withDefault();
    }

    public function Receiver()
    {
        return $this->belongsTo(User::class, 'receiver_id')->withDefault();
    }

    public function LastMessage()
    {
        return $this->hasOne(ChatMessage::class)->orderByDesc('id');
    }

    public function Messages()
    {
        return $this->hasMany(ChatMessage::class);
    }


    public function scopeAnyMember($query, $person_id)
    {
        return $query->where(function (Builder $query) use ($person_id) {
            $query->where('sender_id', $person_id)
                ->orWhere('receiver_id', $person_id);
        });
    }

    public function scopeMe($query, $person_id)
    {
        return $query->where('sender_id', $person_id);
    }

    public function scopeOther($query, $person_id)
    {
        return $query->where('receiver_id', $person_id);
    }

    public function scopeOpened($query)
    {
        return $query->where('status', 'opened');
    }

    public function scopeClosed($query)
    {
        return $query->where('status', 'closed');
    }


    public function UnreadMessagesNotMe()
    {
        return $this->hasMany(ChatMessage::class)->where('is_read', 0)
            ->where('sender_id', '!=', auth('sanctum')->id());
    }
}
