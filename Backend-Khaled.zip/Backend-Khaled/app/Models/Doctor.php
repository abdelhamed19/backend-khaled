<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Casts\Attribute;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;

class Doctor extends Model
{
    use HasFactory;

    protected $fillable = ['name','image','desc','details','cost_examination'];

    protected $casts = ['cost_examination' => 'double'];

    protected $appends = ['image_path'];

    protected function ImagePath(): Attribute
    {
        return Attribute::make(
            get: fn() => asset_url('doctors/'.$this->image),
        );
    }

    public function appointments(): HasMany
    {
        return $this->hasMany(Appointment::class);
    }

}
