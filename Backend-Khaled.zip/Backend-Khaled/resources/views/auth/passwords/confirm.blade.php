{{-- @extends('layouts.app')

@section('content')
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header">{{ __('Confirm Password') }}</div>

                <div class="card-body">
                    {{ __('Please confirm your password before continuing.') }}

                    <form method="POST" action="{{ route('password.confirm') }}">
                        @csrf

                        <div class="row mb-3">
                            <label for="password" class="col-md-4 col-form-label text-md-end">{{ __('Password') }}</label>

                            <div class="col-md-6">
                                <input id="password" type="password" class="form-control @error('password') is-invalid @enderror" name="password" required autocomplete="current-password">

                                @error('password')
                                    <span class="invalid-feedback" role="alert">
                                        <strong>{{ $message }}</strong>
                                    </span>
                                @enderror
                            </div>
                        </div>

                        <div class="row mb-0">
                            <div class="col-md-8 offset-md-4">
                                <button type="submit" class="btn btn-primary">
                                    {{ __('Confirm Password') }}
                                </button>

                                @if (Route::has('password.request'))
                                    <a class="btn btn-link" href="{{ route('password.request') }}">
                                        {{ __('Forgot Your Password?') }}
                                    </a>
                                @endif
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection --}}


@extends('AdminPanel.Auth.layouts.app')
@section('content')

<?php $title = __('site.confirm_pass');?>

    <div class="row justify-content-center">
        <div class="col-md-8 col-lg-6 col-xl-5">
            <div class="card mt-4">

                <div class="card-body p-4">
                    <div class="text-center mt-2">
                        <h5 class="text-primary">{{__('site.new_password')}}</h5>
                        <p class="text-muted">{{__('site.diff_password')}}.</p>
                    </div>

                    <div class="p-2">
                        {!! Form::open(['url' => route('password.confirm')]) !!}
                            <div class="mb-3">
                                {{Form::label('password',__('site.password'),['class' => 'form-label'])}}
                                <div class="position-relative auth-pass-inputgroup">
                                    {!! Form::password('password', ['class'=>'form-control pe-5 password-input','onpaste'=>'return false', 'id'=>"password-input", 'pattern'=>"(?=.*\d)(?=.*[a-z])(?=.*[A-Z]).{8,}"]) !!}
                                    @error('password')<strong class="text-danger">{{$message}}</strong>@enderror
                                    <button class="btn btn-link position-absolute end-0 top-0 text-decoration-none shadow-none text-muted password-addon" type="button" id="password-addon"><i class="ri-eye-fill align-middle"></i></button>
                                </div>
                                <div id="passwordInput" class="form-text">{{__('site.must_characters')}}.</div>
                            </div>

                            <div class="mb-3">
                                {{Form::label('password',__('site.Cpassword'),['class' => 'form-label'])}}
                                <div class="position-relative auth-pass-inputgroup mb-3">
                                    {!! Form::password('password_confirmation', ['class'=>'form-control pe-5 password-input','onpaste'=>'return false', 'id'=>"password-input", 'pattern'=>"(?=.*\d)(?=.*[a-z])(?=.*[A-Z]).{8,}"]) !!}
                                    @error('password_confirmation')<strong class="text-danger">{{$message}}</strong>@enderror
                                    <button class="btn btn-link position-absolute end-0 top-0 text-decoration-none shadow-none text-muted password-addon" type="button" id="confirm-password-input"><i class="ri-eye-fill align-middle"></i></button>
                                </div>
                            </div>

                            <div id="password-contain" class="p-3 bg-light mb-2 rounded">
                                <h5 class="fs-13">{{__('site.pass_contain')}}:</h5>
                                <p id="pass-length" class="invalid fs-12 mb-2">{{__('site.min')}} <b>8 {{__('site.char')}}</b></p>
                                <p id="pass-lower" class="invalid fs-12 mb-2">{{__('site.at')}} <b>{{__('site.lowercase')}}</b> {{__('site.letter')}}</p>
                                <p id="pass-upper" class="invalid fs-12 mb-2">{{__('site.at_least')}} <b>{{__('site.uppercase')}}</b> {{__('site.letter')}}</p>
                                <p id="pass-number" class="invalid fs-12 mb-0">{{__('site.a_least')}} <b>{{__('site.number')}}</b> (0-9)</p>
                            </div>

                            <div class="form-check">
                                {!! Form::checkbox('remember_me',old('remember_me'), ['class' => 'form-check-input']) !!}
                                {!! Form::label('auth-remember-check', __('site.remember_me'), ['class' => 'form-check-label']) !!}
                            </div>

                            <div class="mt-4">
                                {{{!! Form::submit(__('site.reset_password'), ['class'=>'btn btn-success w-100']) !!}}}
                            </div>

                        </form>
                    </div>
                </div>
                <!-- end card body -->
            </div>
            <!-- end card -->

            <div class="mt-4 text-center">
                <p class="mb-0">Wait, I remember my password... <a href="auth-signin-basic.html" class="fw-semibold text-primary text-decoration-underline"> Click here </a> </p>
            </div>

        </div>
    </div>
@stop
