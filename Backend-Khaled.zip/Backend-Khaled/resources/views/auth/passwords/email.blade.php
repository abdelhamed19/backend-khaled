@extends('AdminPanel.Auth.layouts.app')
@section('content')

<?php $title = __('site.reset_password');?>
    <div class="row justify-content-center">
        <div class="col-md-8 col-lg-6 col-xl-5">
            <div class="card mt-4">

                <div class="card-body p-4">
                    <div class="text-center mt-2">
                        <h5 class="text-primary">{{__('site.forget_password')}}</h5>
                        <p class="text-muted">{{__('site.reset_password')." ".__('site.system')}}</p>

                        @if (session('status'))
                            <div class="alert alert-success" role="alert">
                                {{ session('status') }}
                            </div>
                        @endif

                        <lord-icon src="https://cdn.lordicon.com/rhvddzym.json" trigger="loop" colors="primary:#0ab39c" class="avatar-xl">
                        </lord-icon>

                    </div>

                    <div class="alert alert-borderless alert-warning text-center mb-2 mx-2" role="alert">{{__('site.enter_email_instructions')}}</div>
                    <div class="p-2">

                        {{Form::open(['url'=>route('password.email')])}}
                            <div class="mb-4">
                                {{Form::label('email', __('site.email'), ['class'=>'form-label'])}}
                                {{Form::email('email',old('email'), ['class'=>'form-control'])}}
                                @error('email')<strong class="text-danger">{{$message}}</strong>@enderror
                            </div>

                            <div class="text-center mt-4">
                                {{Form::submit(__('site.send_reset'),['class'=> 'btn btn-success w-100'])}}
                            </div>
                        {{Form::close()}}

                    </div>
                </div>
                <!-- end card body -->
            </div>
            <!-- end card -->

            <div class="mt-4 text-center">
                <p class="mb-0">
                    {{__('site.wait_remember_pass')}}
                    <a href="{{route('login')}}" class="fw-semibold text-primary text-decoration-underline"> {{__('site.click_here')}} </a> </p>
            </div>

        </div>
    </div>
    <!-- end row -->
@stop
