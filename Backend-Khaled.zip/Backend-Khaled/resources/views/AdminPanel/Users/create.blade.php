@extends('AdminPanel.layouts.content')
@section('content')

<div class="row">
    <div class="col-lg-12">
        <div class="card">
            <div class="card-header align-items-center d-flex">
                <h4 class="card-title mb-0 flex-grow-1">{{__('site.createNew')}}</h4>
            </div>

            <div class="card-body">
                <div class="live-preview">
                        {!! Form::open(['url' => route('users.store'),'files' => true ,'class'=>'row g-3 needs-validation', 'novalidate']) !!}

                        <div class="col-md-6">
                            {{Form::label('validationCustom01', __('site.fname'), ['class' => 'from-label'])}}
                            {{Form::text('fname', '', ['class' => 'form-control', 'id'=>'validationCustom01'])}}
                            @error('fname') <strong class="text-danger">{{$message}}</strong> @enderror

                            <div class="valid-feedback">{{__('site.good')}}</div>
                        </div>

                        <div class="col-md-6">
                            {{Form::label('validationCustom02', __('site.lname'), ['class' => 'from-label'])}}
                            {{Form::text('lname', '', ['class' => 'form-control', 'id'=>'validationCustom02'])}}
                            @error('lname') <strong class="text-danger">{{$message}}</strong> @enderror

                            <div class="valid-feedback">{{__('site.good')}}</div>
                        </div>

                        <div class="col-md-6">
                            {{Form::label('validationCustom04', __('site.role'), ['class' => 'from-label'])}}
                            {{Form::select('role', getRoles(),'', ['class' => 'form-select', 'id'=>'validationCustom04'])}}

                            @error('role') <strong class="text-danger">{{$message}}</strong> @enderror

                            <div class="valid-feedback">{{__('site.good')}}</div>
                        </div>
                        <div class="col-md-6">
                            {{Form::label('validationCustom04', __('site.usertype'), ['class' => 'from-label'])}}
                            {{Form::select('user_type', [
                              'vendor' =>  __('site.vendor')  ,
                              'client' => __('site.client') ,
                            ],'', ['class' => 'form-select', 'id'=>'validationCustom04'])}}

                            @error('user_type') <strong class="text-danger">{{$message}}</strong> @enderror

                            <div class="valid-feedback">{{__('site.good')}}</div>
                        </div>

                        <div class="col-md-4">
                            {{Form::label('validationCustom03', __('site.phone'), ['class' => 'from-label'])}}
                            {{Form::tel('phone', '', ['class' => 'form-control', 'id'=>'validationCustom03'])}}
                            @error('phone') <strong class="text-danger">{{$message}}</strong> @enderror

                            <div class="valid-feedback">{{__('site.good')}}</div>
                        </div>


                        <div class="col-md-4">
                            {{Form::label('validationCustomUsername', __('site.email'), ['class' => 'from-label'])}}
                            {{Form::email('email', '', ['class' => 'form-control', 'id'=>'validationCustomUsername','aria-describedby'=> "inputGroupPrepend" ])}}

                            @error('email') <strong class="text-danger">{{$message}}</strong> @enderror

                          <div class="invalid-feedback"> Please choose a username. </div>

                        </div>

                        <div class="col-md-4">
                            {{Form::label('validationCustom05', __('site.password'), ['class' => 'from-label'])}}
                            {{Form::password('password', ['class' => 'form-control', 'id'=>'validationCustom05','aria-describedby'=> "inputGroupPrepend" ])}}
                            @error('password') <strong class="text-danger">{{$message}}</strong> @enderror

                            <div class="invalid-feedback"> Please choose a username.</div>
                        </div>

                        <div class="col-md-4">
                            {{Form::label('validationCustom06', __('site.country'), ['class' => 'from-label'])}}
                            {{Form::text('country','', ['class' => 'form-control', 'id'=>'validationCustom06','aria-describedby'=> "inputGroupPrepend" ])}}
                            @error('country') <strong class="text-danger">{{$message}}</strong> @enderror

                            <div class="invalid-feedback"> Please provide a valid city.</div>
                        </div>


                        <div class="col-md-4">
                            {{Form::label('validationCustom07', __('site.city'), ['class' => 'from-label'])}}
                            {{Form::text('city', '',['class' => 'form-control', 'id'=>'validationCustom07','aria-describedby'=> "inputGroupPrepend" ])}}
                            @error('city') <strong class="text-danger">{{$message}}</strong> @enderror

                            <div class="invalid-feedback"> Please provide a valid city.</div>
                        </div>

                        <div class="col-md-4">
                            {{Form::label('validationCustom08', __('site.address'), ['class' => 'from-label'])}}
                            {{Form::text('address','',['class' => 'form-control', 'id'=>'validationCustom08','aria-describedby'=> "inputGroupPrepend" ])}}
                            @error('address') <strong class="text-danger">{{$message}}</strong> @enderror

                            <div class="invalid-feedback"> Please provide a valid city.</div>
                        </div>

                        <div class="mb-3">

                            <div class="col-md-12">
                                {{Form::file('image', ['class' => 'form-control', 'id'=>'validationCustomFile','accept'=>"image/*", 'onchange'=>"previewImage(event)" ])}}
                                @error('image') <strong class="text-danger">{{$message}} </strong> @enderror

                                <div class="invalid-feedback">Example invalid form file feedback</div>

                            </div>
                            <div class="">

                                <img id="preview" src = "#" alt = "new image" />
                            </div>

                        </div>

                        <div class="col-12">
                            {!! Form::submit(__('site.save'), ['class' =>"btn btn-primary" ]) !!}

                        </div>
                    </form>
                </div>

            </div>

        </div>
    </div>
</div> <!-- end col -->


@stop

@stack('scripts')
<script src="{{asset('assets/js/pages/form-validation.init.js')}}"></script>

<script>

   const previewImage = e => {
      const reader = new FileReader();
      reader.readAsDataURL(e.target.files[0]);
      reader.onload = () => {
         const preview = document.getElementById('preview');
         preview.src = reader.result;
      };
   };

</script>
