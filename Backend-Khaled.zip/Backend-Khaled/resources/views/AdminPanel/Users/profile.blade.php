@extends('AdminPanel.layouts.content')
@section('content')

<div class="profile-foreground position-relative mx-n4 mt-n4">
	<div class="profile-wid-bg">
		<img alt="" class="profile-wid-img" src="{{asset('assets/profile-bg-da0d9401.jpg')}}">
    </div>
</div>


<div class="pt-4 mb-4 mb-lg-3 pb-lg-4">
	<div class="g-4 row">

		<div class="col-auto">
			<div class="avatar-lg">
				<img src="{{$user->profilePicture()}}" alt="user-img" class="img-thumbnail rounded-circle">
			</div>
		</div>

		 <div class="col">
			<div class="p-2">
				<h3 class="text-white mb-1">{{$user->name}}</h3>
				<p class="text-white-75">{{$user->user_type}}</p> 
				<div class="hstack text-white-50 gap-1">
					<div class="me-2">
						<i class="ri-map-pin-user-line me-1 text-white-75 fs-16 align-middle"></i>{{$user->city.",".$user->country}}
					</div> 
					<div>
					    <i class="ri-building-line me-1 text-white-75 fs-16 align-middle"></i>{{$user->address}}
				    </div>
				</div>
			</div>
		 </div> 
		 
	</div>
	<div class="d-flex">
		<div class="flex-shrink-0">
			<a href="{{route('users.edit',encrypt($user->id))}}" class="btn btn-success">
			<i class="ri-edit-box-line align-bottom"></i> {{__('site.edit_profile')}}
			</a>
		</div>
	</div>

</div>


<div class="card" style="">
	<div class="card-body">
		<h5 class="card-title mb-3">{{__("site.info")}}</h5>
		<div class="table-responsive">
			<table class="table table-borderless mb-0">
				<tbody>
					<tr>
						<th class="ps-0" scope="row">{{__('site.full_name')}} :</th> 
						<td class="text-muted">{{$user->name}}</td>
					</tr> 
					<tr>
						<th class="ps-0" scope="row">{{__("site.mobile")}} :</th> 
						<td class="text-muted">{{$user->phone}}</td>
					</tr> 
					<tr>
						<th class="ps-0" scope="row">{{__("site.email")}} :</th> 
						<td class="text-muted">{{$user->email}}</td>
					</tr> 
					<tr>
						<th class="ps-0" scope="row">{{__('site.location')}} :</th>
						<td class="text-muted">{{$user->city .",".$user->country}}</td>
					</tr> 
					<tr>
						<th class="ps-0" scope="row">{{__("site.join_date")}}</th> 
						<td class="text-muted">{{$user->created_at}}</td></tr>
				</tbody>
			</table>
		</div>
	</div>
</div> 

@stop