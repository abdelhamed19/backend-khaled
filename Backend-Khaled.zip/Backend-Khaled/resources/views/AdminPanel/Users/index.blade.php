@extends('AdminPanel.layouts.content')
@section('content')

    <div class="row">
        <div class="col-lg-12">

            <div class="card">
                <div class="card-header align-items-center d-flex">
                    <h4 class="card-title mb-0 flex-grow-1">{{$title}}</h4>

                    <div class="flex-shrink-0">
                        <div class="form-check form-switch form-switch-right form-switch-md">

                            <a href="{{route('users.create')}}" class="btn btn-primary w-md waves-effect waves-light">
                                {{__('site.createNew')}}
                            </a>

                            <a href="{{route('users.index',['status'=>'pennding'])}}" class="btn btn-warning w-md waves-effect waves-light">
                                {{__('site.users_pendding')}}
                            </a>

                            <a href="{{route('users.index',['status'=>'block'])}}" class="btn btn-danger w-md waves-effect waves-light">
                                {{__('site.users_inactive')}}
                            </a>



                        </div>
                    </div>

                </div><!-- end card header -->

                <div class="card-body">
                    <div class="live-preview">
                        <div class="table-responsive">
                            <table class="table table-bordered align-middle table-nowrap mb-0">
                                <thead>
                                    <tr>
                                        <th scope="col">#</th>
                                        <th scope="col">{{__('site.name')}}</th>
                                        <th scope="col">{{__('site.email')}}</th>
                                        <th scope="col">{{__('site.photo')}}</th>
                                        <th scope="col">{{__('site.role')}}</th>
                                        <th scope="col">{{__("site.phone")}}</th>
                                        <th scope="col">{{__('site.address')}}</th>
                                       @if(userCan('edit_users') || userCan('delete_users')) 
                                        <th scope="col">{{__('site.actions')}}</th>
                                       @endif 
                                    </tr>
                                </thead>

                                <tbody>
                                    @forelse ($users as $user)
                                        <tr>
                                            <td class="fw-medium">{{$loop->iteration}}</td>
                                            <td>{{$user->name}}</td>
                                            <td>{{$user->email}}</td>
                                            <td><img src="{{$user->profilePicture()}}" width="50%" height="50px" style="position:relative; left:30px"></td>
                                            <td>{{$user->hasRole['name_'.session('locale')] ?? '--'}}</td>
                                            <td>{{$user->phone}}</td>
                                            <td>{{$user->address}}</td>
                                                    
                                           @if(userCan('edit_users') || userCan('delete_users')) 
                                            <td>
                                                <div class="dropdown">
                                                    <a href="#" role="button" id="dropdownMenuLink1" data-bs-toggle="dropdown" aria-expanded="false">
                                                        <i class="ri-more-2-fill"></i>
                                                    </a>

                                                    <ul class="dropdown-menu" aria-labelledby="dropdownMenuLink1">
                                                        <li>
                                                          <a class="dropdown-item" href="{{route('users.changeStatus',$user->id)}}">
                                                          
                                                            <i class="ri-forbid-2-line text-muted me-2 align-bottom"></i>
                                                            {{__('site.change_status')}}
                                                          
                                                          </a>
                                                        </li>

                                                       @if(Route::Is('users.index'))
                                                        <li>
                                                          <a class="dropdown-item" href="{{route('users.show',$user->id)}}">
                                                            <i class="ri-show-bin-6-line text-muted me-2 align-bottom"></i>    {{__('site.show')}}
                                                          </a>
                                                        </li>
                                                        <li>
                                                           <a class="dropdown-item" href="{{route('users.edit',$user->id)}}">
                                                             <i class="ri-pencil-line text-muted me-2 align-bottom"></i> {{__('site.edit')}}
                                                           </a>
                                                        </li>
                                                       @endif


                                                        <li>
                                                          <a class="dropdown-item" href="{{route('users.destroy',$user->id)}}">
                                                            <i class="ri-delete-bin-6-line text-muted me-2 align-bottom"></i>{{__('site.delete')}}
                                                          </a>
                                                        </li>
                                                    
                                                    </ul>
                                                </div>
                                            </td>
                                            @endif
                                        </tr>
                                    @empty
                                    <tr>
                                        <td colspan="6" class="p-3 text-center ">
                                            <h2>{{trans('site.Not_Found_Data')}}</h2>
                                        </td>
                                    </tr>
                                    @endforelse
                                </tbody>
                            </table>
                        </div>
                    </div>
                    </div>
                </div><!-- end card-body -->
            </div><!-- end card -->

        </div>
        <!-- end col -->
    </div>


@stop
