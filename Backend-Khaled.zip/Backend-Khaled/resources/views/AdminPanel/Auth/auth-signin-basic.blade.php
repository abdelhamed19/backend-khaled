@extends('AdminPanel.Auth.layouts.app')
@section('content')
<?php $title = __('site.sign_in');?>

    <div class="row justify-content-center">
        <div class="col-md-8 col-lg-6 col-xl-5">
            <div class="card mt-4 card-bg-fill">

                <div class="card-body p-4">
                    <div class="text-center mt-2">
                        <h5 class="text-primary">{{__('site.welcome_back') }}!</h5>
                        <p class="text-muted">{{__('site.contunie_signin')}}.</p>
                    </div>

                    <div class="p-2 mt-4">
                            {{Form::open(['class' => 'form-horizontal','url' =>route('login')])}}
                            <div class="mb-3">
                                {!! Form::label('email', __('site.email'), ['class' => 'form-label']) !!}
                                {!! Form::email('email', old('email'), ['class' =>'form-control']) !!}
                                @error('email') <strong class="text-danger">{{ $message }}</strong> @enderror
                            </div>

                            <div class="mb-3">
                                <div class="float-end">
                                    @if (Route::has('password.request'))
                                    <a class="btn btn-link text-muted" href="{{ route('password.request') }}">
                                        {{ __('site.forgot_your_password') }}
                                    </a>
                                @endif
                                </div>
                                {!! Form::label('password', __('site.password'), ['class' => 'form-label']) !!}

                                <div class="position-relative auth-pass-inputgroup mb-3">
                                    {!! Form::password('password', ['class' =>'form-control pe-5 password-input']) !!}

                                    <button class="btn btn-link position-absolute end-0 top-0 text-decoration-none text-muted password-addon" type="button" id="password-addon">
                                    <i class="ri-eye-fill align-middle"></i>
                                </button>
                                    @error('password') <strong class="text-danger">{{$message}}</strong> @enderror
                                </div>
                            </div>

                            <div class="form-check">
                                {!! Form::checkbox('remember_me',old('remember_me'), ['class' => 'form-check-input']) !!}
                                {!! Form::label('auth-remember-check', __('site.remember_me'), ['class' => 'form-check-label']) !!}
                            </div>

                            <div class="mt-4">
                                {!! Form::submit(__('site.sign_in'),['class' => 'btn btn-primary w-100']) !!}
                            </div>

                            <!-- <div class="mt-4 text-center">
                                <div class="signin-other-title">
                                    <h5 class="fs-13 mb-4 title">Sign In with</h5>
                                </div>
                                <div>
                                    <button type="button" class="btn btn-primary btn-icon waves-effect waves-light"><i class="ri-facebook-fill fs-16"></i></button>
                                    <button type="button" class="btn btn-danger btn-icon waves-effect waves-light"><i class="ri-google-fill fs-16"></i></button>
                                    <button type="button" class="btn btn-dark btn-icon waves-effect waves-light"><i class="ri-github-fill fs-16"></i></button>
                                    <button type="button" class="btn btn-info btn-icon waves-effect waves-light"><i class="ri-twitter-fill fs-16"></i></button>
                                </div>
                            </div> -->
                        {!!Form::close()!!}
                    </div>

                </div>
                <!-- end card body -->
            </div>
            <!-- end card -->

            {{-- <div class="mt-4 text-center">
                <p class="mb-0">Don't have an account ? <a href="" class="fw-semibold text-primary text-decoration-underline"> Signup </a> </p>
            </div> --}}

        </div>
    </div>
    <!-- end row -->
@stop
