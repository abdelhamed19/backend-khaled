</div>       
</div>    
    <footer class="footer border-top">
        <div class="container-fluid">
            <div class="row">
                <div class="col-sm-6">
                    <script>document.write(new Date().getFullYear())</script> © <a href="https://www.linkedin.com/in/mohaned-elmeleeh">DEV.Mohamed Elmeleeh</a>.
                </div>
                <div class="col-sm-6">
                    <div class="text-sm-end d-none d-sm-block">
                        {{__('site.develop_by')}} DEV.Mohamed Elmeleeh
                    </div>
                </div>
            </div>
        </div>
    </footer>

</div>
    


    <!--start back-to-top-->
    <button onclick="topFunction()" class="btn btn-primary btn-icon" id="back-to-top">
        <i class="ri-arrow-up-line"></i>
    </button>


    <!-- JAVASCRIPT -->
    <script src="{{asset('assets/libs/bootstrap/js/bootstrap.bundle.min.js')}}"></script>
    <script src="{{asset('assets/libs/simplebar/simplebar.min.js')}}"></script>
    <script src="{{asset('assets/libs/node-waves/waves.min.js')}}"></script>
    <script src="{{asset('assets/libs/feather-icons/feather.min.js')}}"></script>
    <script src="{{asset('assets/js/pages/plugins/lord-icon-2.1.0.js')}}"></script>
    <script src="{{asset('assets/js/plugins.js')}}"></script>

 @stack('scripts')
     <!-- prismjs plugin -->
    <script src="{{asset('assets/libs/prismjs/prism.js')}}"></script>

    <!-- gridjs js -->
    <script src="{{asset('assets/libs/gridjs/gridjs.umd.js')}}"></script>
    <!-- gridjs init -->
    <script src="{{asset('assets/js/pages/gridjs.init.js')}}"></script> 


    <script src="{{asset('assets/libs/apexcharts/apexcharts.min.js')}}"></script>
    <script src="{{asset('assets/js/pages/dashboard-projects.init.js')}}"></script>
    <script src="{{asset('assets/js/app.js')}}"></script>

    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>


@if(Session::get('success'))
    <script>
        $(window).on('load',function (){

            Swal.fire({
                position: 'center',
                icon: 'success',
                title: '{{Session::get("success")}}',
                showConfirmButton: false,
                timer: 1500,
                customClass: {
                confirmButton: 'btn btn-primary'
                },
                buttonsStyling: false
            });
        });

    </script>
@endif

@if(Session::get('faild'))
    <script>
        $(window).on('load', function () {
            Swal.fire({
                    position: 'center',
                    icon: 'error',
                    title: '{{Session::get("faild")}}',
                    showConfirmButton: false,
                    timer: 1500,
                    customClass: {
                    confirmButton: 'btn btn-primary'
                    },
                    buttonsStyling: false
                });
        })
    </script>
    {{Session::forget('faild')}}
@endif

</body>

</html>
