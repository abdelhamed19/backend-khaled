<div class="dropdown topbar-head-dropdown ms-1 header-item" id="notificationDropdown">
                        
    <button type="button" class="btn btn-icon btn-topbar btn-ghost-secondary rounded-circle" id="page-header-notifications-dropdown" data-bs-toggle="dropdown" data-bs-auto-close="outside" aria-haspopup="true" aria-expanded="false">
        <i class='bx bx-bell fs-22'></i>
        <span class="position-absolute topbar-badge fs-10 translate-middle badge rounded-pill bg-danger">{{count(auth()->user()->unreadNotifications)}}<span class="visually-hidden">{{__('notify.unread')}}</span></span>
    </button>

    <div class="dropdown-menu dropdown-menu-lg dropdown-menu-end p-0" aria-labelledby="page-header-notifications-dropdown">

        <div class="dropdown-head bg-primary bg-pattern rounded-top">
                             
            <div class="p-3">
                <div class="row align-items-center">
                    <div class="col">
                        <h6 class="m-0 fs-16 fw-semibold text-white"> {{__('site.notifications')}} </h6>
                    </div>
                    
                    <div class="col-auto dropdown-tabs">
                        <span class="badge badge-soft-light fs-13"> {{count(auth()->user()->unreadNotifications)}}</span>
                    </div>
                </div>
            </div>
        </div>

        <div class="tab-content position-relative" id="notificationItemsTabContent">
            <div class="tab-pane fade show active py-2 ps-2" id="all-noti-tab" role="tabpanel">
                <div data-simplebar style="max-height: 300px;" class="pe-2">
                @forelse (auth()->user()->unreadNotifications  as $notification)
                    <div class="text-reset notification-item d-block dropdown-item position-relative">
                       
                        <div class="d-flex">

                            <div class="avatar-xs me-3">
                                <span class="avatar-title bg-soft-info text-info rounded-circle fs-16">
                                    <i class="bx bx-badge-check"></i>
                                </span>
                            </div>

                            <div class="flex-1">
                                <a href="#!" class="stretched-link">
                                    <h6 class="mt-0 mb-2 lh-base">{{$notification->data}}</h6>
                                </a>

                                <p class="mb-0 fs-11 fw-medium text-uppercase text-muted">
                                    <span><i class="mdi mdi-clock-outline"></i> {{$notification->created_at->diffForHumans()}}</span>
                                </p>
                            </div>

                            
                        </div>

                    </div>
                @empty

                <div class="empty-notification-elem">						
                    <div class="text-center pb-5 mt-2">				
                    	<h6 class="fs-18 fw-semibold lh-base">{{__('notify.empty')}} </h6>				
                    </div>
                </div>

                @endforelse

                    <div class="my-3 text-center view-all">
                        <button type="button" class="btn btn-soft-success waves-effect waves-light">View
                            All Notifications <i class="ri-arrow-right-line align-middle"></i></button>
                    </div>
                </div>

            </div>

            
            <div class="notification-actions" id="notification-actions">
                <div class="d-flex text-muted justify-content-center">
                    Select <div id="select-content" class="text-body fw-semibold px-1">0</div> Result 
                    <button type="button" class="btn btn-link link-danger p-0 ms-3" data-bs-toggle="modal" data-bs-target="#removeNotificationModal">Remove</button>
                </div>
            </div>
        </div>
    </div>
</div>
