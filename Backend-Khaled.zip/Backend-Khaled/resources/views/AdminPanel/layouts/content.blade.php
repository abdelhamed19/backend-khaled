
@include('AdminPanel.layouts.header')
@include('AdminPanel.layouts.sidebar')

<div class="main-content">
  <div class="page-content">
    <div class="container-fluid">
      
      @include('AdminPanel.layouts.topbar.breadcrumbs')
      
  
      @yield('content')
    
@include('AdminPanel.layouts.footer')