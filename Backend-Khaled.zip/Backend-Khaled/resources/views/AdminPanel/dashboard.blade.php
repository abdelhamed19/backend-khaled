@extends('AdminPanel.layouts.content')
@section('content')

<div class="row mb-3 pb-1">
    <div class="col-12">
        <div class="d-flex align-items-lg-center flex-lg-row flex-column">
            <div class="flex-grow-1">
                <h4 class="fs-16 mb-1">{{__('site.welcome')}}, {{Auth::user()->name ?? 'guest'}}!</h4>
                <p class="text-muted mb-0">{{__('site.message_welcome')}}.</p>
            </div>
          </div><!-- end card header -->
    </div>
    <!--end col-->
</div>


<div class="row">
    <div class="col-xl-3 col-md-6">
        <!-- card -->
        <div class="card card-animate">
            <div class="card-body">
                <div class="d-flex align-items-center">
                    <div class="flex-grow-1 overflow-hidden">
                        <p class="text-uppercase fw-medium text-muted text-truncate mb-0"> Total Earnings</p>
                    </div>
                    <div class="flex-shrink-0">
                        <h5 class="text-success fs-14 mb-0">
                            <i class="ri-arrow-right-up-line fs-13 align-middle"></i> +16.24 %
                        </h5>
                    </div>
                </div>
                <div class="d-flex align-items-end justify-content-between mt-4">
                    <div>
                        <h4 class="fs-22 fw-semibold ff-secondary mb-4">$<span class="counter-value" data-target="559.25">0</span>k </h4>
                        <a href="" class="text-decoration-underline">View net earnings</a>
                    </div>
                    <div class="avatar-sm flex-shrink-0">
                        <span class="avatar-title bg-success rounded fs-3">
                            <i class="bx bx-dollar-circle"></i>
                        </span>
                    </div>
                </div>
            </div><!-- end card body -->
        </div><!-- end card -->
    </div><!-- end col -->

    <div class="col-xl-3 col-md-6">
        <!-- card -->
        <div class="card card-animate">
            <div class="card-body">
                <div class="d-flex align-items-center">
                    <div class="flex-grow-1 overflow-hidden">
                        <p class="text-uppercase fw-medium text-muted text-truncate mb-0">Orders</p>
                    </div>
                    <div class="flex-shrink-0">
                        <h5 class="text-danger fs-14 mb-0">
                            <i class="ri-arrow-right-down-line fs-13 align-middle"></i> -3.57 %
                        </h5>
                    </div>
                </div>
                <div class="d-flex align-items-end justify-content-between mt-4">
                    <div>
                        <h4 class="fs-22 fw-semibold ff-secondary mb-4"><span class="counter-value" data-target="36894">0</span></h4>
                        <a href="" class="text-decoration-underline">View all orders</a>
                    </div>
                    <div class="avatar-sm flex-shrink-0">
                        <span class="avatar-title bg-info rounded fs-3">
                            <i class="bx bx-shopping-bag"></i>
                        </span>
                    </div>
                </div>
            </div><!-- end card body -->
        </div><!-- end card -->
    </div><!-- end col -->

    <div class="col-xl-3 col-md-6">
        <!-- card -->
        <div class="card card-animate">
            <div class="card-body">
                <div class="d-flex align-items-center">
                    <div class="flex-grow-1 overflow-hidden">
                        <p class="text-uppercase fw-medium text-muted text-truncate mb-0">Customers</p>
                    </div>
                    <div class="flex-shrink-0">
                        <h5 class="text-success fs-14 mb-0">
                            <i class="ri-arrow-right-up-line fs-13 align-middle"></i> +29.08 %
                        </h5>
                    </div>
                </div>
                <div class="d-flex align-items-end justify-content-between mt-4">
                    <div>
                        <h4 class="fs-22 fw-semibold ff-secondary mb-4"><span class="counter-value" data-target="183.35">0</span>M </h4>
                        <a href="" class="text-decoration-underline">See details</a>
                    </div>
                    <div class="avatar-sm flex-shrink-0">
                        <span class="avatar-title bg-warning rounded fs-3">
                            <i class="bx bx-user-circle"></i>
                        </span>
                    </div>
                </div>
            </div><!-- end card body -->
        </div><!-- end card -->
    </div><!-- end col -->

    <div class="col-xl-3 col-md-6">
        <!-- card -->
        <div class="card card-animate">
            <div class="card-body">
                <div class="d-flex align-items-center">
                    <div class="flex-grow-1 overflow-hidden">
                        <p class="text-uppercase fw-medium text-muted text-truncate mb-0"> My Balance</p>
                    </div>
                    <div class="flex-shrink-0">
                        <h5 class="text-muted fs-14 mb-0">
                            +0.00 %
                        </h5>
                    </div>
                </div>
                <div class="d-flex align-items-end justify-content-between mt-4">
                    <div>
                        <h4 class="fs-22 fw-semibold ff-secondary mb-4">$<span class="counter-value" data-target="165.89">0</span>k </h4>
                        <a href="" class="text-decoration-underline">Withdraw money</a>
                    </div>
                    <div class="avatar-sm flex-shrink-0">
                        <span class="avatar-title bg-danger rounded fs-3">
                            <i class="bx bx-wallet"></i>
                        </span>
                    </div>
                </div>
            </div><!-- end card body -->
        </div><!-- end card -->
    </div><!-- end col -->
</div>

<div class="row">
  <div class="col-xl-12">
      <div class="card card-height-100">

          <div class="card-header align-items-center d-flex">
              <h4 class="card-title mb-0 flex-grow-1">Store Visits by Source</h4>
              <div class="flex-shrink-0">
                  <div class="dropdown card-header-dropdown">
                      <a class="text-reset dropdown-btn" href="#" data-bs-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                          <span class="text-muted">Report<i class="mdi mdi-chevron-down ms-1"></i></span>
                      </a>
                      <div class="dropdown-menu dropdown-menu-end">
                          <a class="dropdown-item" href="#">Download Report</a>
                          <a class="dropdown-item" href="#">Export</a>
                          <a class="dropdown-item" href="#">Import</a>
                      </div>
                  </div>
              </div>
          </div><!-- end card header -->

          <div class="card-body">
            <div id="store-visits-source" data-colors="[&quot;--vz-primary&quot;, &quot;--vz-success&quot;, &quot;--vz-warning&quot;, &quot;--vz-danger&quot;, &quot;--vz-info&quot;]" class="apex-charts" dir="ltr" style="min-height: 300.7px;">
            <div id="apexcharts2tvuvvsw" class="apexcharts-canvas apexcharts2tvuvvsw apexcharts-theme-light" style="width: 302px; height: 300.7px;"><svg id="SvgjsSvg1120" width="302" height="300.7" xmlns="http://www.w3.org/2000/svg" version="1.1" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svgjs="http://svgjs.dev" class="apexcharts-svg" xmlns:data="ApexChartsNS" transform="translate(0, 0)" style="background: transparent;">
              <foreignObject x="0" y="0" width="302" height="300.7">

                <div class="apexcharts-legend apexcharts-align-center apx-legend-position-bottom" xmlns="http://www.w3.org/1999/xhtml" style="inset: auto 0px 1px; position: absolute; max-height: 166.5px;">
                  <div class="apexcharts-legend-series" style="margin: 2px 5px;" rel="1" seriesname="Direct" data:collapsed="false">
                    <span class="apexcharts-legend-marker" style="background: rgb(75, 56, 179) !important; color: rgb(75, 56, 179); height: 12px; width: 12px; left: 0px; top: 0px; border-width: 0px; border-color: rgb(255, 255, 255); border-radius: 12px;" rel="1" data:collapsed="false"></span>
                    <span class="apexcharts-legend-text" style="color: rgb(55, 61, 63); font-size: 12px; font-weight: 400; font-family: Helvetica, Arial, sans-serif;" rel="1" i="0" data:default-text="Direct" data:collapsed="false">Direct</span>
                  </div>

                  <div class="apexcharts-legend-series" style="margin: 2px 5px;" rel="2" seriesname="Social" data:collapsed="false">
                    <span class="apexcharts-legend-marker" style="background: rgb(69, 203, 133) !important; color: rgb(69, 203, 133); height: 12px; width: 12px; left: 0px; top: 0px; border-width: 0px; border-color: rgb(255, 255, 255); border-radius: 12px;" rel="2" data:collapsed="false"></span>
                    <span class="apexcharts-legend-text" style="color: rgb(55, 61, 63); font-size: 12px; font-weight: 400; font-family: Helvetica, Arial, sans-serif;" rel="2" i="1" data:default-text="Social" data:collapsed="false">Social</span>
                  </div>

                  <div class="apexcharts-legend-series" style="margin: 2px 5px;" rel="3" seriesname="Email" data:collapsed="false">
                    <span class="apexcharts-legend-marker" style="background: rgb(255, 190, 11) !important; color: rgb(255, 190, 11); height: 12px; width: 12px; left: 0px; top: 0px; border-width: 0px; border-color: rgb(255, 255, 255); border-radius: 12px;" rel="3" data:collapsed="false"></span>
                    <span class="apexcharts-legend-text" style="color: rgb(55, 61, 63); font-size: 12px; font-weight: 400; font-family: Helvetica, Arial, sans-serif;" rel="3" i="2" data:default-text="Email" data:collapsed="false">Email</span>
                  </div>

                  <div class="apexcharts-legend-series" style="margin: 2px 5px;" rel="4" seriesname="Other" data:collapsed="false">
                    <span class="apexcharts-legend-marker" style="background: rgb(240, 101, 72) !important; color: rgb(240, 101, 72); height: 12px; width: 12px; left: 0px; top: 0px; border-width: 0px; border-color: rgb(255, 255, 255); border-radius: 12px;" rel="4" data:collapsed="false"></span>
                    <span class="apexcharts-legend-text" style="color: rgb(55, 61, 63); font-size: 12px; font-weight: 400; font-family: Helvetica, Arial, sans-serif;" rel="4" i="3" data:default-text="Other" data:collapsed="false">Other</span>
                  </div>

                  <div class="apexcharts-legend-series" style="margin: 2px 5px;" rel="5" seriesname="Referrals" data:collapsed="false">
                    <span class="apexcharts-legend-marker" style="background: rgb(41, 156, 219) !important; color: rgb(41, 156, 219); height: 12px; width: 12px; left: 0px; top: 0px; border-width: 0px; border-color: rgb(255, 255, 255); border-radius: 12px;" rel="5" data:collapsed="false"></span>
                    <span class="apexcharts-legend-text" style="color: rgb(55, 61, 63); font-size: 12px; font-weight: 400; font-family: Helvetica, Arial, sans-serif;" rel="5" i="4" data:default-text="Referrals" data:collapsed="false">Referrals</span>
                  </div>

                </div>

                <style type="text/css">

                          .apexcharts-legend {
                            display: flex;
                            overflow: auto;
                            padding: 0 10px;
                          }
                          .apexcharts-legend.apx-legend-position-bottom, .apexcharts-legend.apx-legend-position-top {
                            flex-wrap: wrap
                          }
                          .apexcharts-legend.apx-legend-position-right, .apexcharts-legend.apx-legend-position-left {
                            flex-direction: column;
                            bottom: 0;
                          }
                          .apexcharts-legend.apx-legend-position-bottom.apexcharts-align-left, .apexcharts-legend.apx-legend-position-top.apexcharts-align-left, .apexcharts-legend.apx-legend-position-right, .apexcharts-legend.apx-legend-position-left {
                            justify-content: flex-start;
                          }
                          .apexcharts-legend.apx-legend-position-bottom.apexcharts-align-center, .apexcharts-legend.apx-legend-position-top.apexcharts-align-center {
                            justify-content: center;
                          }
                          .apexcharts-legend.apx-legend-position-bottom.apexcharts-align-right, .apexcharts-legend.apx-legend-position-top.apexcharts-align-right {
                            justify-content: flex-end;
                          }
                          .apexcharts-legend-series {
                            cursor: pointer;
                            line-height: normal;
                          }
                          .apexcharts-legend.apx-legend-position-bottom .apexcharts-legend-series, .apexcharts-legend.apx-legend-position-top .apexcharts-legend-series{
                            display: flex;
                            align-items: center;
                          }
                          .apexcharts-legend-text {
                            position: relative;
                            font-size: 14px;
                          }
                          .apexcharts-legend-text *, .apexcharts-legend-marker * {
                            pointer-events: none;
                          }
                          .apexcharts-legend-marker {
                            position: relative;
                            display: inline-block;
                            cursor: pointer;
                            margin-right: 3px;
                            border-style: solid;
                          }

                          .apexcharts-legend.apexcharts-align-right .apexcharts-legend-series, .apexcharts-legend.apexcharts-align-left .apexcharts-legend-series{
                            display: inline-block;
                          }
                          .apexcharts-legend-series.apexcharts-no-click {
                            cursor: auto;
                          }
                          .apexcharts-legend .apexcharts-hidden-zero-series, .apexcharts-legend .apexcharts-hidden-null-series {
                            display: none !important;
                          }
                          .apexcharts-inactive-legend {
                            opacity: 0.45;
                          }
                </style>

            </foreignObject>

            <g id="SvgjsG1122" class="apexcharts-inner apexcharts-graphical" transform="translate(12, 0)">
              <defs id="SvgjsDefs1121">
                <clipPath id="gridRectMask2tvuvvsw">
                  <rect id="SvgjsRect1124" width="286" height="250" x="-3" y="-1" rx="0" ry="0" opacity="1" stroke-width="0" stroke="none" stroke-dasharray="0" fill="#fff"></rect>
                </clipPath>
                <clipPath id="forecastMask2tvuvvsw"></clipPath>
                <clipPath id="nonForecastMask2tvuvvsw"></clipPath>
                <clipPath id="gridRectMarkerMask2tvuvvsw">
                  <rect id="SvgjsRect1125" width="284" height="252" x="-2" y="-2" rx="0" ry="0" opacity="1" stroke-width="0" stroke="none" stroke-dasharray="0" fill="#fff"></rect>
                </clipPath>
              </defs>

              <g id="SvgjsG1126" class="apexcharts-pie">
                <g id="SvgjsG1127" transform="translate(0, 0) scale(1)">
                  <circle id="SvgjsCircle1128" r="74.73414634146341" cx="140" cy="124" fill="transparent"></circle>
                  <g id="SvgjsG1129" class="apexcharts-slices">
                    <g id="SvgjsG1130" class="apexcharts-series apexcharts-pie-series" seriesName="Direct" rel="1" data:realIndex="0">
                      <path id="SvgjsPath1131" d="M 140 9.024390243902431 A 114.97560975609757 114.97560975609757 0 0 1 254.89890359066607 128.19914187058058 L 214.68428733393296 126.72944221587737 A 74.73414634146341 74.73414634146341 0 0 0 140 49.265853658536585 L 140 9.024390243902431 z" fill="rgba(75,56,179,1)" fill-opacity="1" stroke-opacity="1" stroke-linecap="butt" stroke-width="0" stroke-dasharray="0" class="apexcharts-pie-area apexcharts-donut-slice-0" index="0" j="0" data:angle="92.09302325581395" data:startAngle="0" data:strokeWidth="0" data:value="44" data:pathOrig="M 140 9.024390243902431 A 114.97560975609757 114.97560975609757 0 0 1 254.89890359066607 128.19914187058058 L 214.68428733393296 126.72944221587737 A 74.73414634146341 74.73414634146341 0 0 0 140 49.265853658536585 L 140 9.024390243902431 z"></path>
                    </g>
                    <g id="SvgjsG1134" class="apexcharts-series apexcharts-pie-series" seriesName="Social" rel="2" data:realIndex="1">
                      <path id="SvgjsPath1135" d="M 254.89890359066607 128.19914187058058 A 114.97560975609757 114.97560975609757 0 0 1 87.42828507175449 226.2526558495657 L 105.82838529664042 190.4642263022177 A 74.73414634146341 74.73414634146341 0 0 0 214.68428733393296 126.72944221587737 L 254.89890359066607 128.19914187058058 z" fill="rgba(69,203,133,1)" fill-opacity="1" stroke-opacity="1" stroke-linecap="butt" stroke-width="0" stroke-dasharray="0" class="apexcharts-pie-area apexcharts-donut-slice-1" index="0" j="1" data:angle="115.11627906976746" data:startAngle="92.09302325581395" data:strokeWidth="0" data:value="55" data:pathOrig="M 254.89890359066607 128.19914187058058 A 114.97560975609757 114.97560975609757 0 0 1 87.42828507175449 226.2526558495657 L 105.82838529664042 190.4642263022177 A 74.73414634146341 74.73414634146341 0 0 0 214.68428733393296 126.72944221587737 L 254.89890359066607 128.19914187058058 z"></path>
                    </g>
                    <g id="SvgjsG1138" class="apexcharts-series apexcharts-pie-series" seriesName="Email" rel="3" data:realIndex="2">
                      <path id="SvgjsPath1139" d="M 87.42828507175449 226.2526558495657 A 114.97560975609757 114.97560975609757 0 0 1 34.18263635743858 79.0324962831562 L 71.21871363233508 94.77112258405154 A 74.73414634146341 74.73414634146341 0 0 0 105.82838529664042 190.4642263022177 L 87.42828507175449 226.2526558495657 z" fill="rgba(255,190,11,1)" fill-opacity="1" stroke-opacity="1" stroke-linecap="butt" stroke-width="0" stroke-dasharray="0" class="apexcharts-pie-area apexcharts-donut-slice-2" index="0" j="2" data:angle="85.81395348837208" data:startAngle="207.2093023255814" data:strokeWidth="0" data:value="41" data:pathOrig="M 87.42828507175449 226.2526558495657 A 114.97560975609757 114.97560975609757 0 0 1 34.18263635743858 79.0324962831562 L 71.21871363233508 94.77112258405154 A 74.73414634146341 74.73414634146341 0 0 0 105.82838529664042 190.4642263022177 L 87.42828507175449 226.2526558495657 z"></path></g><g id="SvgjsG1142" class="apexcharts-series apexcharts-pie-series" seriesName="Other" rel="4" data:realIndex="3"><path id="SvgjsPath1143" d="M 34.18263635743858 79.0324962831562 A 114.97560975609757 114.97560975609757 0 0 1 80.10456670585107 25.857614104340243 L 101.0679683588032 60.20744916782116 A 74.73414634146341 74.73414634146341 0 0 0 71.21871363233508 94.77112258405154 L 34.18263635743858 79.0324962831562 z" fill="rgba(240,101,72,1)" fill-opacity="1" stroke-opacity="1" stroke-linecap="butt" stroke-width="0" stroke-dasharray="0" class="apexcharts-pie-area apexcharts-donut-slice-3" index="0" j="3" data:angle="35.58139534883719" data:startAngle="293.0232558139535" data:strokeWidth="0" data:value="17" data:pathOrig="M 34.18263635743858 79.0324962831562 A 114.97560975609757 114.97560975609757 0 0 1 80.10456670585107 25.857614104340243 L 101.0679683588032 60.20744916782116 A 74.73414634146341 74.73414634146341 0 0 0 71.21871363233508 94.77112258405154 L 34.18263635743858 79.0324962831562 z"></path></g><g id="SvgjsG1146" class="apexcharts-series apexcharts-pie-series" seriesName="Referrals" rel="5" data:realIndex="4"><path id="SvgjsPath1147" d="M 80.10456670585107 25.857614104340243 A 114.97560975609757 114.97560975609757 0 0 1 139.97993297060455 9.024391995081103 L 139.98695643089295 49.265854796802714 A 74.73414634146341 74.73414634146341 0 0 0 101.0679683588032 60.20744916782116 L 80.10456670585107 25.857614104340243 z" fill="rgba(41,156,219,1)" fill-opacity="1" stroke-opacity="1" stroke-linecap="butt" stroke-width="0" stroke-dasharray="0" class="apexcharts-pie-area apexcharts-donut-slice-4" index="0" j="4" data:angle="31.395348837209326" data:startAngle="328.6046511627907" data:strokeWidth="0" data:value="15" data:pathOrig="M 80.10456670585107 25.857614104340243 A 114.97560975609757 114.97560975609757 0 0 1 139.97993297060455 9.024391995081103 L 139.98695643089295 49.265854796802714 A 74.73414634146341 74.73414634146341 0 0 0 101.0679683588032 60.20744916782116 L 80.10456670585107 25.857614104340243 z"></path>
                    </g>
                    <g id="SvgjsG1132" class="apexcharts-datalabels">
                      <text id="SvgjsText1133" font-family="Helvetica, Arial, sans-serif" x="208.28635621020817" y="58.16367685554131" text-anchor="middle" dominant-baseline="auto" font-size="12px" font-weight="600" fill="#ffffff" class="apexcharts-text apexcharts-pie-label" style="font-family: Helvetica, Arial, sans-serif;">25.6%</text>
                    </g>
                    <g id="SvgjsG1136" class="apexcharts-datalabels">
                      <text id="SvgjsText1137" font-family="Helvetica, Arial, sans-serif" x="187.92669562834791" y="205.85645811905567" text-anchor="middle" dominant-baseline="auto" font-size="12px" font-weight="600" fill="#ffffff" class="apexcharts-text apexcharts-pie-label" style="font-family: Helvetica, Arial, sans-serif;">32.0%</text>
                    </g>
                    <g id="SvgjsG1140" class="apexcharts-datalabels">
                      <text id="SvgjsText1141" font-family="Helvetica, Arial, sans-serif" x="50.79991458710893" y="156.26131819969476" text-anchor="middle" dominant-baseline="auto" font-size="12px" font-weight="600" fill="#ffffff" class="apexcharts-text apexcharts-pie-label" style="font-family: Helvetica, Arial, sans-serif;">23.8%</text>
                    </g>
                    <g id="SvgjsG1144" class="apexcharts-datalabels">
                      <text id="SvgjsText1145" font-family="Helvetica, Arial, sans-serif" x="68.21042273067496" y="62.0023832301545" text-anchor="middle" dominant-baseline="auto" font-size="12px" font-weight="600" fill="#ffffff" class="apexcharts-text apexcharts-pie-label" style="font-family: Helvetica, Arial, sans-serif;">9.9%</text>
                    </g>
                    <g id="SvgjsG1148" class="apexcharts-datalabels">
                      <text id="SvgjsText1149" font-family="Helvetica, Arial, sans-serif" x="114.33593414839571" y="32.68295003881511" text-anchor="middle" dominant-baseline="auto" font-size="12px" font-weight="600" fill="#ffffff" class="apexcharts-text apexcharts-pie-label" style="font-family: Helvetica, Arial, sans-serif;">8.7%</text>
                    </g>
                  </g>
                </g>
              </g>
              <line id="SvgjsLine1150" x1="0" y1="0" x2="280" y2="0" stroke="#b6b6b6" stroke-dasharray="0" stroke-width="1" stroke-linecap="butt" class="apexcharts-ycrosshairs"></line>
              <line id="SvgjsLine1151" x1="0" y1="0" x2="280" y2="0" stroke-dasharray="0" stroke-width="0" stroke-linecap="butt" class="apexcharts-ycrosshairs-hidden"></line>
            </g>
            <g id="SvgjsG1123" class="apexcharts-annotations"></g></svg>
            <div class="apexcharts-tooltip apexcharts-theme-dark" style="left: 191.108px; top: -10.2333px;">
            <div class="apexcharts-tooltip-series-group apexcharts-active" style="order: 1; display: flex; background-color: rgb(75, 56, 179);"><span class="apexcharts-tooltip-marker" style="background-color: rgb(75, 56, 179); display: none;"></span>
            <div class="apexcharts-tooltip-text" style="font-family: Helvetica, Arial, sans-serif; font-size: 12px;">

            <div class="apexcharts-tooltip-y-group">
              <span class="apexcharts-tooltip-text-y-label">Direct: </span>
              <span class="apexcharts-tooltip-text-y-value">44</span>
            </div>

            <div class="apexcharts-tooltip-goals-group">
              <span class="apexcharts-tooltip-text-goals-label"></span>
              <span class="apexcharts-tooltip-text-goals-value"></span>
            </div>

            <div class="apexcharts-tooltip-z-group">
              <span class="apexcharts-tooltip-text-z-label"></span>
              <span class="apexcharts-tooltip-text-z-value"></span>
            </div>

          </div>

      </div>

      <div class="apexcharts-tooltip-series-group" style="order: 2; display: none; background-color: rgb(75, 56, 179);">
        <span class="apexcharts-tooltip-marker" style="background-color: rgb(75, 56, 179); display: none;"></span>
        <div class="apexcharts-tooltip-text" style="font-family: Helvetica, Arial, sans-serif; font-size: 12px;">
        <div class="apexcharts-tooltip-y-group">
          <span class="apexcharts-tooltip-text-y-label">Direct: </span>
          <span class="apexcharts-tooltip-text-y-value">44</span>
        </div>
        <div class="apexcharts-tooltip-goals-group">
          <span class="apexcharts-tooltip-text-goals-label"></span>
          <span class="apexcharts-tooltip-text-goals-value"></span>
        </div>
        <div class="apexcharts-tooltip-z-group">
          <span class="apexcharts-tooltip-text-z-label"></span>
          <span class="apexcharts-tooltip-text-z-value"></span>
        </div>
      </div>
      </div>
      <div class="apexcharts-tooltip-series-group" style="order: 3; display: none; background-color: rgb(75, 56, 179);">
          <span class="apexcharts-tooltip-marker" style="background-color: rgb(75, 56, 179); display: none;"></span>
          <div class="apexcharts-tooltip-text" style="font-family: Helvetica, Arial, sans-serif; font-size: 12px;">
          <div class="apexcharts-tooltip-y-group">
            <span class="apexcharts-tooltip-text-y-label">Direct: </span>
            <span class="apexcharts-tooltip-text-y-value">44</span>
          </div>
          <div class="apexcharts-tooltip-goals-group">
            <span class="apexcharts-tooltip-text-goals-label"></span>
            <span class="apexcharts-tooltip-text-goals-value"></span>
          </div>
          <div class="apexcharts-tooltip-z-group">
            <span class="apexcharts-tooltip-text-z-label"></span>
            <span class="apexcharts-tooltip-text-z-value"></span>
          </div>
      </div>
      </div>

      <div class="apexcharts-tooltip-series-group" style="order: 4; display: none; background-color: rgb(75, 56, 179);">
        <span class="apexcharts-tooltip-marker" style="background-color: rgb(75, 56, 179); display: none;"></span>
        <div class="apexcharts-tooltip-text" style="font-family: Helvetica, Arial, sans-serif; font-size: 12px;">
            <div class="apexcharts-tooltip-y-group">
              <span class="apexcharts-tooltip-text-y-label">Direct: </span>
              <span class="apexcharts-tooltip-text-y-value">44</span>
            </div>
            <div class="apexcharts-tooltip-goals-group">
          <span class="apexcharts-tooltip-text-goals-label"></span>
          <span class="apexcharts-tooltip-text-goals-value"></span>
            </div>
            <div class="apexcharts-tooltip-z-group">
              <span class="apexcharts-tooltip-text-z-label"></span>
              <span class="apexcharts-tooltip-text-z-value"></span>
            </div>
        </div>
      </div>

      <div class="apexcharts-tooltip-series-group" style="order: 5; display: none; background-color: rgb(75, 56, 179);">
        <span class="apexcharts-tooltip-marker" style="background-color: rgb(75, 56, 179); display: none;"></span>
        <div class="apexcharts-tooltip-text" style="font-family: Helvetica, Arial, sans-serif; font-size: 12px;">
          <div class="apexcharts-tooltip-y-group">
            <span class="apexcharts-tooltip-text-y-label">Direct: </span>
            <span class="apexcharts-tooltip-text-y-value">44</span>
          </div>
          <div class="apexcharts-tooltip-goals-group">
            <span class="apexcharts-tooltip-text-goals-label"></span>
            <span class="apexcharts-tooltip-text-goals-value"></span>
          </div>
          <div class="apexcharts-tooltip-z-group">
            <span class="apexcharts-tooltip-text-z-label"></span>
            <span class="apexcharts-tooltip-text-z-value"></span>
          </div>

        </div>
      </div>

</div>

</div>
</div>

          </div>
      </div> <!-- .card-->
  </div> <!-- .col-->

</div>
@endSection
