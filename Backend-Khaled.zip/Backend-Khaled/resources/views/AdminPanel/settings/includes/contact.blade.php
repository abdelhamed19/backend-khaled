<!-- form -->
<div class="row">
    <div class="col-12 col-md-4">
       {{Form::label('phone',__('site.phone'), ['class'=> 'form-label'])}} 
       {{Form::text('phone',getSettingValue('phone'),['id'=>'phone','class'=>'form-control'])}}
    </div>
    <div class="col-12 col-md-4">
       {{Form::label('mobile',__('site.mobile'), ['class'=> 'form-label'])}} 
       {{Form::text('mobile',getSettingValue('mobile'),['id'=>'mobile','class'=>'form-control'])}}
    </div>
    <div class="col-12 col-md-4">
       {{Form::label('email',__('site.email'), ['class'=> 'form-label'])}} 
       {{Form::text('email',getSettingValue('email'),['id'=>'email','class'=>'form-control'])}}
    </div>
    <div class="col-12 col-md-12">
       {{Form::label('addres',__('site.addres'), ['class'=> 'form-label'])}} 
       {{Form::textarea('address',getSettingValue('address'),['id'=>'address','class'=>'form-control','rows'=>'3'])}}
       
    </div>

</div>
<!--/ form -->