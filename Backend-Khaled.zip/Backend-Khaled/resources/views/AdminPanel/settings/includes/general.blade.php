<!-- form -->
<div class="row">
    
    <div class="col-12 col-md-3">   
        {{-- {{Form::select('sales_agent_role_id',getRolesList('ar','id'),getSettingValue('sales_agent_role_id'),['id'=>'sales_agent_role_id', 'class'=>'form-select'])}} --}}
    </div>
</div>
<!--/ form -->