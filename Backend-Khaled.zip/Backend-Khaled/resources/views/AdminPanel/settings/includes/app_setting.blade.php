<!-- form -->
<div class="row">

    <div class="col-3 col-md-4">
        {{Form::label('start_price',trans('site.start_price') , ['class' => "form-label"])}}
        {{Form::text('start_price',getSettingValue('start_price'),['id'=>'start_price','class'=>'form-control'])}}
    </div>
    <div class="col-3 col-md-4">
        {{Form::label('tariff_price',trans('site.tariff_price') , ['class' => "form-label"])}}
        {{Form::text('tariff_price',getSettingValue('tariff_price'),['id'=>'tariff_price','class'=>'form-control'])}}
    </div>

    <div class="col-3 col-md-4">
        {{Form::label('minute_wait_price',trans('site.minute_wait_price') , ['class' => "form-label"])}}
        {{Form::text('minute_wait_price',getSettingValue('minute_wait_price'),['id'=>'minute_wait_price','class'=>'form-control'])}}
    </div>
    <div class="col-3 col-md-4">
        {{Form::label('cancelling_price',trans('site.cancelling_price') , ['class' => "form-label"])}}
        {{Form::text('cancelling_price',getSettingValue('cancelling_price'),['id'=>'cancelling_price','class'=>'form-control'])}}
    </div>
    <div class="col-3 col-md-4">
        {{Form::label('PricePerKilo',trans('site.PricePerKilo') , ['class' => "form-label"])}}
        {{Form::text('PricePerKilo',getSettingValue('PricePerKilo'),['id'=>'PricePerKilo','class'=>'form-control'])}}
    </div>


</div>
<!--/ form -->
