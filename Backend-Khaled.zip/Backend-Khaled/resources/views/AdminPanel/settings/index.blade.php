@extends('AdminPanel.layouts.content')
@section('content')

    <div class="row" id="table-bordered">
        <div class="col-12">
            {{Form::open(['url'=>route('settings.update'), 'files'=>'true'])}}

            <div class="card">
                <div class="card-body">
                    <ul class="nav nav-tabs" role="tablist">
                        <li class="nav-item">
                            <a class="nav-link active" id="hr-tab" data-bs-toggle="tab" href="#app" aria-controls="home" role="tab" aria-selected="true">
                                <i data-feather="home"></i> {{trans('site.app_setting')}}
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" id="accounts-tab" data-bs-toggle="tab" href="#accounts" aria-controls="accounts" role="tab" aria-selected="false">
                                <i data-feather="tool"></i> {{trans('site.accountsSettings')}}
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" id="contact-tab" data-bs-toggle="tab" href="#contact" aria-controls="contact" role="tab" aria-selected="false">
                                <i data-feather="message-square"></i> {{trans('site.contactSettings')}}
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" id="general-tab" data-bs-toggle="tab" href="#general" aria-controls="general" role="tab" aria-selected="false">
                                <i data-feather="tool"></i> {{trans('site.generalSettings')}}
                            </a>
                        </li>
                    </ul>
                    <div class="tab-content">
                        <div class="tab-pane active" id="app" aria-labelledby="hr-tab" role="tabpanel">
                            @include('AdminPanel.settings.includes.app_setting')
                        </div>
                        <div class="tab-pane" id="accounts" aria-labelledby="accounts-tab" role="tabpanel">
                            @include('AdminPanel.settings.includes.accounts')
                        </div>
                        <div class="tab-pane" id="contact" aria-labelledby="contact-tab" role="tabpanel">
                            @include('AdminPanel.settings.includes.contact')
                        </div>
                        <div class="tab-pane" id="general" aria-labelledby="general-tab" role="tabpanel">
                            @include('AdminPanel.settings.includes.general')
                        </div>
                    </div>
                </div>
                <div class="card-footer">
                    <input type="submit" value="{{trans('site.save')}}" class="btn btn-primary">
                </div>
            </div>
            {{Form::close()}}
        </div>
    </div>
    <!-- Bordered table end -->
@stop
