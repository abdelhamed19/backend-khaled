<?php
return [
    'server-internal-error'      => 'خطأ في الخادم',
    'request-done-successfully'  => 'الطلب تم بنجاح',
    'not_found'                  => 'لا يوجد بيانات',
];


?>
