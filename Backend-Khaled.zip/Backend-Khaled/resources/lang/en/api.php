<?php
return [
    'server-internal-error'         => 'Internal Server Error',
    'request-done-successfully'     => 'Request Done Successfully',
    'code-successfully'             => 'User Check Code Is Successfully ,than Go To Login',
    'register-successfully'         => 'User Logged IN Successfully ,than Go To Check code',
    'resend-successfully'           => 'User Resend Code Successfully ,than Go To Check code',
    'login-done'                    => 'Log In Successfully',
    'logout-done'                   => 'Logout Successfully',
    'not_found'                     => 'Not Found',
    'not_doctor'                    => 'This is Not :var',
    'patient_not_match'             => 'Patient Is Not Match',
    'not_available'                 => 'Appointment IS Not Available',
    'must-verify'                   => 'Must Verify Code',
    'must-login'                    => 'Must Login',

    'successReset'                   => 'Password Reset Successfully',
    'update-success'                 => 'Updated Successfully',
    'notify-read-success'            => 'Notification Has Been Read',
    'notify-read-all'                => 'All Notifications Have Been Read',

    'errorTech'                     => 'Error Technical Contact Support Service',
    'errorUser'                     => 'User Is Not Found.',
    'errorPass'                     => 'Old Password Is Not Matched.',
    'error_pass'                    => 'Password Is Not Matched.',
    'expire'                        => 'Time Is Expire.',

    ];


?>
