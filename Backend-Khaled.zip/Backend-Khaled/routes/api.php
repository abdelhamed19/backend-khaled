<?php

use App\Http\Controllers\Api\{AdviceController,
    BookingController,
    DoctorController,
    GameController,
    HomeController,
    NoteController,
    NotificationController,
    QuestionController,
    SettingController,
    SplashController,
    UserController,
    AgoraController,
    VirtualActivityController,
    ScoreRecordController,
    ChatController
};
use App\Http\Controllers\Auth\{ForgotPasswordController, LoginController, RegisterController, ResetPasswordController};
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| Here is where you can register API routes for your application. These
| routes are loaded by the RouteServiceProvider and all of them will
| be assigned to the "api" middleware group. Make something great!
|
*/

Route::middleware('auth:sanctum')->get('/user', function (Request $request) {
    return $request->user();
});

Route::group(['prefix' => 'settings'], function () {
    Route::get('all', [SettingController::class, 'all']);
    Route::get('show/{id}', [SettingController::class, 'show']);
});

Route::get('splashs', [SplashController::class, 'index']);
Route::post('register', [RegisterController::class, 'register']);
Route::post('login', [LoginController::class, 'login']);
Route::post('recover/password', [ForgotPasswordController::class, 'recoverPassword']);
Route::post('check/code', [ForgotPasswordController::class, 'checkCode']);
Route::get('resend/code', [ForgotPasswordController::class, 'resendCode']);
Route::post('reset/password', [ResetPasswordController::class, 'resetPassword']);


Route::group(['middleware' => ['auth:sanctum']], function () {
    Route::post('logout', [LoginController::class, 'logout']);

    Route::group(['prefix' => 'games'], function () {
        Route::get('all', [GameController::class, 'index']);
    });

    Route::group(['prefix' => 'users'], function () {
        Route::post('/edit/profile', [UserController::class, 'editProfile']);
        Route::post('/change/status', [UserController::class, 'changeNotificationStatus']);
    });

    Route::group(['prefix' => 'doctors'], function () {
        Route::get('all', [DoctorController::class, 'index']);
        Route::get('show/{id}', [DoctorController::class, 'show']);
        Route::get('edit', [DoctorController::class, 'edit']);
    });

    Route::group(['prefix' => 'patients'], function () {
        Route::get('all', [UserController::class, 'allPatient']);
        Route::get('appointments', [UserController::class, 'appointmentPatients']);
        Route::get('show', [UserController::class, 'showPatient']);
        Route::get('edit', [UserController::class, 'edit']);
    });

    Route::group(['prefix' => 'booking'], function () {
        Route::post('appointment', [BookingController::class, 'appointment']);
        Route::post('payment', [BookingController::class, 'payment']);
    });

    Route::group(['prefix' => 'notes'], function () {
        Route::get('all', [NoteController::class, 'index']);
        Route::post('create', [NoteController::class, 'store']);
        Route::post('check/{id}', [NoteController::class, 'update']);
    });

    Route::get('home', [HomeController::class, 'index']);
    Route::post('feedback', [HomeController::class, 'feed']);
    Route::get('more', [HomeController::class, 'more']);
    Route::get('page/{id}', [HomeController::class, 'showStaticPage']);

    Route::group(['prefix' => 'questions'], function () {
        Route::get('home', [QuestionController::class, 'index']);
        Route::get('show/{id}', [QuestionController::class, 'show']);
        Route::post('answer/{id}', [QuestionController::class, 'answer']);
        Route::get('result', [QuestionController::class, 'showResult']);
    });

    Route::group(['prefix' => 'advices'], function () {
        Route::get('advice', [AdviceController::class, 'index']);
        Route::get('show/{num?}', [AdviceController::class, 'showAll']);
    });

    Route::group(['prefix' => 'notifications'], function () {
        Route::get('all', [NotificationController::class, 'index']);
        Route::get('read/{notification_id}', [NotificationController::class, 'read']);
        Route::get('show/{notification_id}', [NotificationController::class, 'show']);
        Route::get('make_all_read', [NotificationController::class, 'readAll']);
        Route::get('delete', [NotificationController::class, 'deleteAll']);
    });


    /* agora*/
    Route::post('get-agora-token/{id}', [AgoraController::class, 'getAgoraToken']);

    /* chats */
    Route::get('my-chats', [ChatController::class, 'myChats']);
    Route::post('open-chat', [ChatController::class, 'openChat']);
    Route::post('send-message', [ChatController::class, 'sendMessage']);
    Route::post('close-chats', [ChatController::class, 'closeChats']);

    /* letters */
    Route::get('letters', [HomeController::class, 'letters']);
    /* virtual activities */
    Route::group(['prefix' => 'virtual-activities'], function () {
        Route::get('/', [VirtualActivityController::class, 'index']);
        Route::post('store-or-update', [VirtualActivityController::class, 'storeOrUpdate']);
    });
    /* score-records */
    Route::group(['prefix' => 'score-records'], function () {
        Route::get('/', [ScoreRecordController::class, 'index']);
        Route::post('store-or-update', [ScoreRecordController::class, 'storeOrUpdate']);
    });
});
?>
