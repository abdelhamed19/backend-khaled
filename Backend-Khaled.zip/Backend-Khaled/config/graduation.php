<?php

return [
    /* agora */
    'agora' => [
        'app_id' => '76cdb3d0836b4d8dafdc7ad5cd4d7452',
        'certificate' => '55dbfeb666fb41a9913543dce3168042'
    ]
];
