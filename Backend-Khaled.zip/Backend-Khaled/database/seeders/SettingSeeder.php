<?php

namespace Database\Seeders;

use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class SettingSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        DB::table('settings')->insert([
            ['id' => 1, 'key' => 'logo_app', 'value' => 'logo.jpg', 'label' => 'logo', 'type' => 'App', 'created_at' => '2023-12-18 23:35:58', 'updated_at' => '2023-12-18 23:35:58'],
            ['id' => 2, 'key' => 'name_app', 'value' => 'ADHD', 'label' => 'name_app', 'type' => 'App', 'created_at' => '2023-12-18 23:35:58', 'updated_at' => '2023-12-18 23:35:58'],
            ['id' => 3, 'key' => 'logo', 'value' => 'logo.png', 'label' => 'logo_app', 'type' => 'App', 'created_at' => '2023-12-18 23:35:58', 'updated_at' => '2023-12-18 23:35:58'],
            ['id' => 4, 'key' => 'home', 'value' => 'home.jpg', 'label' => 'image', 'type' => 'Home', 'created_at' => '2023-12-18 23:35:58', 'updated_at' => '2023-12-18 23:35:58'],
            ['id' => 5, 'key' => 'Depression', 'value' => 'Depression test', 'label' => 'Your daily mental health coach', 'type' => 'Others', 'created_at' => '2023-12-18 23:35:58', 'updated_at' => '2023-12-18 23:35:58'],
            ['id' => 6, 'key' => 'anxiety', 'value' => 'anxiety test', 'label' => 'Your daily mental health coach', 'type' => 'Others', 'created_at' => '2023-12-18 23:35:58', 'updated_at' => '2023-12-18 23:35:58'],
            ['id' => 7, 'key' => 'bipolar', 'value' => 'bipolar test', 'label' => 'Your daily mental health coach', 'type' => 'Others', 'created_at' => '2023-12-18 23:35:58', 'updated_at' => '2023-12-18 23:35:58'],
            ['id' => 8, 'key' => 'PTSD', 'value' => 'PTSD Test', 'label' => 'Your daily mental health coach', 'type' => 'Others', 'created_at' => '2023-12-18 23:35:58', 'updated_at' => '2023-12-18 23:35:58'],
        ]);


    }
}
