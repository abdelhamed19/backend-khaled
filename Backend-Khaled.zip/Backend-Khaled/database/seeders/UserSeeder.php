<?php

namespace Database\Seeders;

use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Hash;

class UserSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        DB::table('users')->insert([
            ['id' => '2','first_name' => 'mostafa','last_name' => 'ahmed','Id_number' => '12345678912378','user_type' => 'patient','email' => 'patient@app.com','password' => Hash::make('12345678'),'phone' => '01247852368','image' => 'patient.png','created_at' => '2023-12-14 23:02:03','updated_at' => '2023-12-14 23:02:03'],
            ['id' => '3','first_name' => 'ahmed','last_name' => 'mahmoud','Id_number' => '12345678912345','user_type' => 'patient','email' => 'ahmed@gmail.com','password'  => Hash::make('11112222'),'phone' => '01054785236','image' => 'doctor.jpg','created_at' => '2023-12-14 23:29:02','updated_at' => '2023-12-14 23:29:02'],
            ['id' => '4','first_name' => 'mahmoud','last_name' => 'ahmed','Id_number' => '12345678912344','user_type' => 'patient','email' => 'mahmoud@gmail.com','password'  => Hash::make('11111111'),'phone' => '01054785234','image' => 'doctor_2.jpg','created_at' => '2023-12-15 00:04:47','updated_at' => '2023-12-15 00:04:47']
        ]);

        DB::table('otps')->insert([
            ['id' => '2','user_id' => 2,'code' => 1111,'expire' => '2023-12-14 23:02:03','created_at' => '2023-12-14 23:02:03','updated_at' => '2023-12-14 23:02:03'],
            ['id' => '3','user_id' => 3,'code' => 1111,'expire' => '2023-12-14 23:29:02','created_at' => '2023-12-14 23:29:02','updated_at' => '2023-12-14 23:29:02'],
            ['id' => '4','user_id' => 4,'code' => 1111,'expire' => '2023-12-15 12:16:47','created_at' => '2023-12-15 00:04:47','updated_at' => '2023-12-15 00:04:47']
        ]);

        DB::table('doctors')->insert([

                ['id' => '1','name' => 'ahmed', 'image'=>'ahmed.jpg',
                 'desc' => 'description data fack description data fack','cost_examination' => 50.00,
                 'details' => 'details data fack details data fack details data fack details data fack',
                 'created_at' => '2023-12-15 03:01:54','updated_at' => '2023-12-15 03:01:54'],

                ['id' => '2','name' => 'mohab', 'image' => 'mohab.jpg',
                 'desc' => 'description data fack description data fack','cost_examination' => 100.00,
                 'details' => 'details data fack details data fack details data fack details data fack',
                 'created_at' => '2023-12-15 03:01:54','updated_at' => '2023-12-15 03:01:54'],

               ['id' => '3','name' => 'alaa', 'image' => 'alaa.jpg',
                 'desc' => 'description data fack description data fack','cost_examination' => 150.00,
                 'details' => 'details data fack details data fack details data fack details data fack',
                 'created_at' => '2023-12-15 03:01:54','updated_at' => '2023-12-15 03:01:54'],

              ['id' => '4','name' => 'hamza', 'image' => 'hamza.jpg',
                 'desc' => 'description data fack description data fack','cost_examination' => 200.00,
                 'details' => 'details data fack details data fack details data fack details data fack',
                 'created_at' => '2023-12-15 03:01:54','updated_at' => '2023-12-15 03:01:54']
        ]);

        DB::table('appointments')->insert([
            ['id'=>1,'doctor_id' =>1 , 'time'=>'10:00:40' , 'date' => '2024-08-22','created_at' => '2023-12-15 03:01:54','updated_at' => '2023-12-15 03:01:54'],
            ['id'=>2,'doctor_id' =>1 , 'time'=>'13:00:22' , 'date' => '2024-09-25','created_at' => '2023-12-15 03:01:54','updated_at' => '2023-12-15 03:01:54'],
            ['id'=>3,'doctor_id' =>2 , 'time'=>'11:00:22' , 'date' => '2024-10-20','created_at' => '2023-12-15 03:01:54','updated_at' => '2023-12-15 03:01:54'],
            ['id'=>4,'doctor_id' =>2 , 'time'=>'09:00:50' , 'date' => '2024-08-15','created_at' => '2023-12-15 03:01:54','updated_at' => '2023-12-15 03:01:54'],
            ['id'=>5,'doctor_id' =>3 , 'time'=>'14:00:15' , 'date' => '2024-09-16','created_at' => '2023-12-15 03:01:54','updated_at' => '2023-12-15 03:01:54'],
            ['id'=>6,'doctor_id' =>3 , 'time'=>'15:00:42' , 'date' => '2024-07-10','created_at' => '2023-12-15 03:01:54','updated_at' => '2023-12-15 03:01:54'],
            ['id'=>7,'doctor_id' =>4 , 'time'=>'18:00:38' , 'date' => '2024-07-09','created_at' => '2023-12-15 03:01:54','updated_at' => '2023-12-15 03:01:54'],
            ['id'=>8,'doctor_id' =>4 , 'time'=>'20:00:02' , 'date' => '2024-05-23','created_at' => '2023-12-15 03:01:54','updated_at' => '2023-12-15 03:01:54'],
        ]);
    }
}
