<?php

namespace Database\Seeders;

use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class SplashSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        for ($i = 1; $i <= 3; $i++) {

            DB::table('splashes')->insert([
                'id' => $i,
                'title' => 'page'.$i,
                'body' => 'splash_page splash_page splash_page',
                'image' => 'splashes_page'.$i.'.png',
            ]);
        }
    }
}
