<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('advice', function (Blueprint $table) {
            $table->id();
            $table->string('title');
            $table->text('details');
            $table->timestamps();
        });


        DB::table('advice')->insert([
          ['id' => 1, 'title' => 'Note about adhd', 'details' => 'The prescribed drugs do more harm than the condition itself Beware of Medication It is no wonder that
                all ADHD medication is controlled by prescription and black striped - because it might cause addiction. This addiction and the side effects can be very strong and many times go unnoticed or mainly get confused with strong personality. 
                It is worth remembering that many of the meds for ADHD have a chemical structure very similar to that of cocaine', 'created_at' => '2023-12-18 23:35:58', 'updated_at' => '2023-12-18 23:35:58'],
            ['id' => 2, 'title' => 'Note about adhd', 'details' => 'ADHD is different between boys and girls Truth: This condition is more common in boys.Boys with ADHD are generally more hyperactive and impulsive, which causes more discomfort at home and at school. Girls with ADHD are more inattentive, disconnected and sometimes not hyperactive at all, which leads to a more difficult diagnosis ', 'created_at' => '2023-12-18 23:35:58', 'updated_at' => '2023-12-18 23:35:58'],
            ['id' => 3, 'title' => 'Note about adhd', 'details' => 'It is important to note that eventually you will rush or forget something or actually make a wrong decision and something will go wrong, but remember that this is normal', 'created_at' => '2023-12-18 23:35:58', 'updated_at' => '2023-12-18 23:35:58'],
            ['id' => 4, 'title' => 'Note about adhd', 'details' => 'ADHD it\'s not a disease, it\'s a benefit normally people with ADHD are extremely smart, but many times they might not use their full potential. People with ADHD usually have a high IQ, but given the way that our brain works we need to use different techniques in which can make the best of us', 'created_at' => '2023-12-18 23:35:58', 'updated_at' => '2023-12-18 23:35:58'],

            ['id' => 5, 'title' => 'In school', 'details' => 'Educate Yourself It helps to be familiar with laws, regulations, and policies that can support your child', 'created_at' => '2023-12-18 23:35:58', 'updated_at' => '2023-12-18 23:35:58'],
            ['id' => 6, 'title' => 'In school', 'details' => 'social skills groups. These are small gatherings – usually between two and eight kids – that are led by a school psychologist or speech therapist. They can help kids learn how to connect with their peers and handle certain social situations', 'created_at' => '2023-12-18 23:35:58', 'updated_at' => '2023-12-18 23:35:58'],
            ['id' => 7, 'title' => 'In school', 'details' => 'Call the school and arrange to share report cards, test scores, and notes from last year. Meet with the guidance counselor and your child\'s teachers. You may need to update their plan or make a new one', 'created_at' => '2023-12-18 23:35:58', 'updated_at' => '2023-12-18 23:35:58'],
            ['id' => 8, 'title' => 'In school', 'details' => 'Ask the guidance counselor to take you and your child on a tour of theschool. Meet with teachers, the principal, the nurse, and anyone else your child will see daily. Walk through the whole school day with your child so they know where they need to go and when. If possible, try to arrange a playdate or hangout with another student from your child’s new class', 'created_at' => '2023-12-18 23:35:58', 'updated_at' => '2023-12-18 23:35:58'],
            ['id' => 9, 'title' => 'In school', 'details' => 'Meet with teachers to talk about your child\'s needs and goals, and see what the teacher can do to help them in class', 'created_at' => '2023-12-18 23:35:58', 'updated_at' => '2023-12-18 23:35:58'],

           ['id' => 10, 'title' => 'Mange your mood', 'details' => 'Kids with ADHD have the same feelings as people without the condition. Joy, anger, fear, sadness -- the list goes on. Their emotions are just stronger, happen more often, and last longer. They also tend to impact everyday life', 'created_at' => '2023-12-18 23:35:58', 'updated_at' => '2023-12-18 23:35:58'],
           ['id' => 11, 'title' => 'Mange your mood', 'details' => 'As a parent or caregiver, it may be hard to understand why your child acts the way they do. You might think they’re just being difficult. But it’s important to remember they’re not doing it on purpose. For them, learning to control their behavior may take more time and effort. Here’s what you need to know', 'created_at' => '2023-12-18 23:35:58', 'updated_at' => '2023-12-18 23:35:58'],
           ['id' => 12, 'title' => 'Mange your mood', 'details' => 'There’s no one way a child with ADHD expresses their emotions. One kid’s feelings may spiral out of control when they’re upset. Others may have trouble finding the motivation to do something that doesn’t interest them.', 'created_at' => '2023-12-18 23:35:58', 'updated_at' => '2023-12-18 23:35:58'],
           ['id' => 13, 'title' => 'Mange your mood', 'details' => 'Don’t downplay your child’s feelings. Kids need a safe space to talk about their emotions. Do your best to listen more than you ask questions. And try to put yourself in their shoes. Emotions that don’t make sense to you are still real to your child.', 'created_at' => '2023-12-18 23:35:58', 'updated_at' => '2023-12-18 23:35:58'],
           ['id' => 14, 'title' => 'Mange your mood', 'details' => 'Make a list of coping skills. These are ways to help your child feel better during stressful moments without hurting themselves or others. Some skills work better in public and others at home. Here are a few things they can try:', 'created_at' => '2023-12-18 23:35:58', 'updated_at' => '2023-12-18 23:35:58'],

        ]);


    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('advice');
    }
};
