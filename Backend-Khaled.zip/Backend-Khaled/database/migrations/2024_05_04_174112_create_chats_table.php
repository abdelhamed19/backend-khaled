<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('chats', function (Blueprint $table) {
            $table->increments('id')->unsigned();
            $table->unsignedInteger('sender_id')->nullable();
            $table->enum('sender_status', ['off', 'on'])->default('off');
            $table->unsignedInteger('receiver_id')->nullable();
            $table->enum('receiver_status', ['off', 'on'])->default('off');
            $table->enum('status', ['opened', 'closed'])->default('opened');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('chats');
    }
};
