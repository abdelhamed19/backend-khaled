<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('sections', function (Blueprint $table) {
            $table->id();
            $table->string('title');
            $table->string('subtitle');
            $table->string('image');
            $table->timestamps();
        });

        DB::table('sections')->insert([
            ['id' => 1, 'title' => 'Not Sure Its ADHD?', 'subtitle' => 'Complete Free Assessment', 'image' => 'test.png', 'created_at' => '2023-12-18 23:35:58', 'updated_at' => '2023-12-18 23:35:58'],
            ['id' => 2, 'title' => 'Do You Want Some Advice ADHD?', 'subtitle' => 'Take Some Advice', 'image' => 'advice.png', 'created_at' => '2023-12-18 23:35:58', 'updated_at' => '2023-12-18 23:35:58'],
            ['id' => 3, 'title' => 'Not To Mother', 'subtitle' => 'Follow Up With Dr',  'image' => 'notes.png', 'created_at' => '2023-12-18 23:35:58', 'updated_at' => '2023-12-18 23:35:58'],
        ]);

    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('sections');
    }
};
