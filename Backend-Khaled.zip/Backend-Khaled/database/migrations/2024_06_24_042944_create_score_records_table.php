<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('score_records', function (Blueprint $table) {
            $table->id();
            $table->unsignedBigInteger('user_id')->nullable();
            $table->decimal('saturday_score')->default(0);
            $table->decimal('sunday_score')->default(0);
            $table->decimal('monday_score')->default(0);
            $table->decimal('tuesday_score')->default(0);
            $table->decimal('wednesday_score')->default(0);
            $table->decimal('thursday_score')->default(0);
            $table->decimal('friday_score')->default(0);
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('score_records');
    }
};
