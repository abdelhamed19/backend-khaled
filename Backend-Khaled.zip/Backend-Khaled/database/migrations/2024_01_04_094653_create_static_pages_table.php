<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('static_pages', function (Blueprint $table) {
            $table->id();
            $table->string('title');
            $table->string('details');
            $table->string('image');
            $table->timestamps();
        });


        DB::table('static_pages')->insert([

            ['id' => 1, 'title' => 'help', 'details' => 'Lorem ipsum dolor sit amet, consectetur adipiscing elit ut aliquamLorem ipsum dolor sit amet,consectetur adipiscing elit ut aliquam.?..','image'=>'help.jpg' ,'created_at' => '2023-12-18 23:35:58', 'updated_at' => '2023-12-18 23:35:58'],
            ['id' => 2, 'title' => 'terms and privacy', 'details' => 'Lorem ipsum dolor sit amet, consectetur adipiscing elit ut aliquamLorem ipsum dolor sit amet,consectetur adipiscing elit ut aliquam.?..','image'=>'privacy.jpg', 'created_at' => '2023-12-18 23:35:58', 'updated_at' => '2023-12-18 23:35:58'],

        ]);
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('static_pages');
    }
};
