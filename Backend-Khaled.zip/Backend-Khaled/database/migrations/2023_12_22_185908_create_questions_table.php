<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('questions', function (Blueprint $table) {
            $table->id();
            $table->text('question');
            $table->text('answers');
            $table->text('correct');
            $table->timestamps();
        });


        DB::table('questions')->insert([
            ['id'=>1, 'question'=>'Lorem ipsum dolor sit amet?','answers'=>"never,always,sometimes,usually", 'correct'=>'never','created_at' => '2023-12-18 23:35:58', 'updated_at' => '2023-12-18 23:35:58'],
            ['id'=>2, 'question'=>'Lorem ipsum dolor sit amet?','answers'=>"never,always,sometimes,usually", 'correct'=>'always','created_at' => '2023-12-18 23:35:58', 'updated_at' => '2023-12-18 23:35:58'],
            ['id'=>3, 'question'=>'Lorem ipsum dolor sit amet?','answers'=>"never,always,sometimes,usually", 'correct'=>'sometimes','created_at' => '2023-12-18 23:35:58', 'updated_at' => '2023-12-18 23:35:58'],
            ['id'=>4, 'question'=>'Lorem ipsum dolor sit amet?','answers'=>"never,always,sometimes,usually", 'correct'=>'usually','created_at' => '2023-12-18 23:35:58', 'updated_at' => '2023-12-18 23:35:58'],
            ['id'=>5, 'question'=>'Lorem ipsum dolor sit amet?','answers'=>"never,always,sometimes,usually", 'correct'=>'usually','created_at' => '2023-12-18 23:35:58', 'updated_at' => '2023-12-18 23:35:58'],
            ['id'=>6, 'question'=>'Lorem ipsum dolor sit amet?','answers'=>"never,always,sometimes,usually", 'correct'=>'sometimes','created_at' => '2023-12-18 23:35:58', 'updated_at' => '2023-12-18 23:35:58'],
            ['id'=>7, 'question'=>'Lorem ipsum dolor sit amet?','answers'=>"never,always,sometimes,usually", 'correct'=>'sometimes','created_at' => '2023-12-18 23:35:58', 'updated_at' => '2023-12-18 23:35:58'],
            ['id'=>8, 'question'=>'Lorem ipsum dolor sit amet?','answers'=>"never,always,sometimes,usually", 'correct'=>'always','created_at' => '2023-12-18 23:35:58', 'updated_at' => '2023-12-18 23:35:58'],
            ['id'=>9, 'question'=>'Lorem ipsum dolor sit amet?','answers'=>"never,always,sometimes,usually", 'correct'=>'never','created_at' => '2023-12-18 23:35:58', 'updated_at' => '2023-12-18 23:35:58'],
        ]);

    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('questions');
    }
};
