<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('games', function (Blueprint $table) {
            $table->id();
            $table->string('image');
            $table->timestamps();
        });

        DB::table('games')->insert([
            ['id'=>1,'image'=>'download_1.jpg','created_at'=>now(),'updated_at'=>now()],
            ['id'=>2,'image'=>'download_2.jpg','created_at'=>now(),'updated_at'=>now()],
            ['id'=>3,'image'=>'download_3.jpg','created_at'=>now(),'updated_at'=>now()],
            ['id'=>4,'image'=>'download_4.jpg','created_at'=>now(),'updated_at'=>now()],
            ['id'=>5,'image'=>'download_5.jpg','created_at'=>now(),'updated_at'=>now()],
            ['id'=>6,'image'=>'download_6.jpg','created_at'=>now(),'updated_at'=>now()],
            ['id'=>7,'image'=>'download_7.jpg','created_at'=>now(),'updated_at'=>now()],
            ['id'=>8,'image'=>'download_8.jpg','created_at'=>now(),'updated_at'=>now()],
            ['id'=>9,'image'=>'download_9.jpg','created_at'=>now(),'updated_at'=>now()],
            ['id'=>10,'image'=>'download_10.jpg','created_at'=>now(),'updated_at'=>now()],
        ]);
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('games');
    }
};
