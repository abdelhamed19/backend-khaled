-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: Jun 24, 2024 at 03:22 AM
-- Server version: 8.0.30
-- PHP Version: 8.1.10

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `graduation`
--

-- --------------------------------------------------------

--
-- Table structure for table `advice`
--

CREATE TABLE `advice` (
  `id` bigint UNSIGNED NOT NULL,
  `title` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `details` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `advice`
--

INSERT INTO `advice` (`id`, `title`, `details`, `created_at`, `updated_at`) VALUES
(1, 'Note about adhd', 'The prescribed drugs do more harm than the condition itself Beware of Medication It is no wonder that\n                all ADHD medication is controlled by prescription and black striped - because it might cause addiction. This addiction and the side effects can be very strong and many times go unnoticed or mainly get confused with strong personality. \n                It is worth remembering that many of the meds for ADHD have a chemical structure very similar to that of cocaine', '2023-12-18 20:35:58', '2023-12-18 20:35:58'),
(2, 'Note about adhd', 'ADHD is different between boys and girls Truth: This condition is more common in boys.Boys with ADHD are generally more hyperactive and impulsive, which causes more discomfort at home and at school. Girls with ADHD are more inattentive, disconnected and sometimes not hyperactive at all, which leads to a more difficult diagnosis ', '2023-12-18 20:35:58', '2023-12-18 20:35:58'),
(3, 'Note about adhd', 'It is important to note that eventually you will rush or forget something or actually make a wrong decision and something will go wrong, but remember that this is normal', '2023-12-18 20:35:58', '2023-12-18 20:35:58'),
(4, 'Note about adhd', 'ADHD it\'s not a disease, it\'s a benefit normally people with ADHD are extremely smart, but many times they might not use their full potential. People with ADHD usually have a high IQ, but given the way that our brain works we need to use different techniques in which can make the best of us', '2023-12-18 20:35:58', '2023-12-18 20:35:58'),
(5, 'In school', 'Educate Yourself It helps to be familiar with laws, regulations, and policies that can support your child', '2023-12-18 20:35:58', '2023-12-18 20:35:58'),
(6, 'In school', 'social skills groups. These are small gatherings – usually between two and eight kids – that are led by a school psychologist or speech therapist. They can help kids learn how to connect with their peers and handle certain social situations', '2023-12-18 20:35:58', '2023-12-18 20:35:58'),
(7, 'In school', 'Call the school and arrange to share report cards, test scores, and notes from last year. Meet with the guidance counselor and your child\'s teachers. You may need to update their plan or make a new one', '2023-12-18 20:35:58', '2023-12-18 20:35:58'),
(8, 'In school', 'Ask the guidance counselor to take you and your child on a tour of theschool. Meet with teachers, the principal, the nurse, and anyone else your child will see daily. Walk through the whole school day with your child so they know where they need to go and when. If possible, try to arrange a playdate or hangout with another student from your child’s new class', '2023-12-18 20:35:58', '2023-12-18 20:35:58'),
(9, 'In school', 'Meet with teachers to talk about your child\'s needs and goals, and see what the teacher can do to help them in class', '2023-12-18 20:35:58', '2023-12-18 20:35:58'),
(10, 'Mange your mood', 'Kids with ADHD have the same feelings as people without the condition. Joy, anger, fear, sadness -- the list goes on. Their emotions are just stronger, happen more often, and last longer. They also tend to impact everyday life', '2023-12-18 20:35:58', '2023-12-18 20:35:58'),
(11, 'Mange your mood', 'As a parent or caregiver, it may be hard to understand why your child acts the way they do. You might think they’re just being difficult. But it’s important to remember they’re not doing it on purpose. For them, learning to control their behavior may take more time and effort. Here’s what you need to know', '2023-12-18 20:35:58', '2023-12-18 20:35:58'),
(12, 'Mange your mood', 'There’s no one way a child with ADHD expresses their emotions. One kid’s feelings may spiral out of control when they’re upset. Others may have trouble finding the motivation to do something that doesn’t interest them.', '2023-12-18 20:35:58', '2023-12-18 20:35:58'),
(13, 'Mange your mood', 'Don’t downplay your child’s feelings. Kids need a safe space to talk about their emotions. Do your best to listen more than you ask questions. And try to put yourself in their shoes. Emotions that don’t make sense to you are still real to your child.', '2023-12-18 20:35:58', '2023-12-18 20:35:58'),
(14, 'Mange your mood', 'Make a list of coping skills. These are ways to help your child feel better during stressful moments without hurting themselves or others. Some skills work better in public and others at home. Here are a few things they can try:', '2023-12-18 20:35:58', '2023-12-18 20:35:58');

-- --------------------------------------------------------

--
-- Table structure for table `appointments`
--

CREATE TABLE `appointments` (
  `id` bigint UNSIGNED NOT NULL,
  `doctor_id` bigint UNSIGNED NOT NULL,
  `patient_id` bigint UNSIGNED DEFAULT NULL,
  `date` date DEFAULT NULL,
  `time` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'new',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `appointments`
--

INSERT INTO `appointments` (`id`, `doctor_id`, `patient_id`, `date`, `time`, `status`, `created_at`, `updated_at`) VALUES
(1, 1, NULL, '2024-08-22', '10:00:40', 'new', '2023-12-15 00:01:54', '2023-12-15 00:01:54'),
(2, 1, NULL, '2024-09-25', '13:00:22', 'new', '2023-12-15 00:01:54', '2023-12-15 00:01:54'),
(3, 2, NULL, '2024-10-20', '11:00:22', 'new', '2023-12-15 00:01:54', '2023-12-15 00:01:54'),
(4, 2, NULL, '2024-08-15', '09:00:50', 'new', '2023-12-15 00:01:54', '2023-12-15 00:01:54'),
(5, 3, NULL, '2024-09-16', '14:00:15', 'new', '2023-12-15 00:01:54', '2023-12-15 00:01:54'),
(6, 3, NULL, '2024-07-10', '15:00:42', 'new', '2023-12-15 00:01:54', '2023-12-15 00:01:54'),
(7, 4, NULL, '2024-07-09', '18:00:38', 'new', '2023-12-15 00:01:54', '2023-12-15 00:01:54'),
(8, 4, NULL, '2024-05-23', '20:00:02', 'new', '2023-12-15 00:01:54', '2023-12-15 00:01:54');

-- --------------------------------------------------------

--
-- Table structure for table `chats`
--

CREATE TABLE `chats` (
  `id` int UNSIGNED NOT NULL,
  `sender_id` int UNSIGNED DEFAULT NULL,
  `sender_status` enum('off','on') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'off',
  `receiver_id` int UNSIGNED DEFAULT NULL,
  `receiver_status` enum('off','on') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'off',
  `status` enum('opened','closed') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'opened',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `chats`
--

INSERT INTO `chats` (`id`, `sender_id`, `sender_status`, `receiver_id`, `receiver_status`, `status`, `created_at`, `updated_at`) VALUES
(1, 5, 'off', 2, 'on', 'opened', '2024-05-04 04:25:00', '2024-05-04 05:18:50');

-- --------------------------------------------------------

--
-- Table structure for table `chat_messages`
--

CREATE TABLE `chat_messages` (
  `id` bigint UNSIGNED NOT NULL,
  `chat_id` int UNSIGNED DEFAULT NULL,
  `sender_id` int UNSIGNED DEFAULT NULL,
  `message_type` enum('text','image','voice') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'text',
  `message` varchar(512) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `is_read` tinyint(1) NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `chat_messages`
--

INSERT INTO `chat_messages` (`id`, `chat_id`, `sender_id`, `message_type`, `message`, `is_read`, `created_at`, `updated_at`) VALUES
(1, 1, 5, 'text', 'hi mostafa', 0, '2024-05-04 05:04:33', '2024-05-04 05:04:33'),
(2, 1, 5, 'text', 'hi mostafa 2', 0, '2024-05-04 05:04:47', '2024-05-04 05:04:47'),
(3, 1, 5, 'image', '202405040805182070.jpg', 0, '2024-05-04 05:05:18', '2024-05-04 05:05:18'),
(4, 1, 5, 'image', '202405040807426101.jpg', 0, '2024-05-04 05:07:42', '2024-05-04 05:07:42'),
(5, 1, 5, 'voice', '202405040808342944.mp3', 0, '2024-05-04 05:08:34', '2024-05-04 05:08:34');

-- --------------------------------------------------------

--
-- Table structure for table `doctors`
--

CREATE TABLE `doctors` (
  `id` bigint UNSIGNED NOT NULL,
  `name` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `image` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `desc` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `cost_examination` double DEFAULT NULL,
  `details` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `doctors`
--

INSERT INTO `doctors` (`id`, `name`, `image`, `desc`, `cost_examination`, `details`, `created_at`, `updated_at`) VALUES
(1, 'ahmed', 'ahmed.jpg', 'description data fack description data fack', 50, 'details data fack details data fack details data fack details data fack', '2023-12-15 00:01:54', '2023-12-15 00:01:54'),
(2, 'mohab', 'mohab.jpg', 'description data fack description data fack', 100, 'details data fack details data fack details data fack details data fack', '2023-12-15 00:01:54', '2023-12-15 00:01:54'),
(3, 'alaa', 'alaa.jpg', 'description data fack description data fack', 150, 'details data fack details data fack details data fack details data fack', '2023-12-15 00:01:54', '2023-12-15 00:01:54'),
(4, 'hamza', 'hamza.jpg', 'description data fack description data fack', 200, 'details data fack details data fack details data fack details data fack', '2023-12-15 00:01:54', '2023-12-15 00:01:54');

-- --------------------------------------------------------

--
-- Table structure for table `failed_jobs`
--

CREATE TABLE `failed_jobs` (
  `id` bigint UNSIGNED NOT NULL,
  `uuid` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `connection` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `queue` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `exception` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `feedback`
--

CREATE TABLE `feedback` (
  `id` bigint UNSIGNED NOT NULL,
  `user_id` bigint UNSIGNED NOT NULL,
  `rate` enum('1','2','3','4','5') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `message` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `games`
--

CREATE TABLE `games` (
  `id` bigint UNSIGNED NOT NULL,
  `image` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `games`
--

INSERT INTO `games` (`id`, `image`, `created_at`, `updated_at`) VALUES
(1, 'download_1.jpg', '2024-05-02 06:55:01', '2024-05-02 06:55:01'),
(2, 'download_2.jpg', '2024-05-02 06:55:01', '2024-05-02 06:55:01'),
(3, 'download_3.jpg', '2024-05-02 06:55:01', '2024-05-02 06:55:01'),
(4, 'download_4.jpg', '2024-05-02 06:55:01', '2024-05-02 06:55:01'),
(5, 'download_5.jpg', '2024-05-02 06:55:01', '2024-05-02 06:55:01'),
(6, 'download_6.jpg', '2024-05-02 06:55:01', '2024-05-02 06:55:01'),
(7, 'download_7.jpg', '2024-05-02 06:55:01', '2024-05-02 06:55:01'),
(8, 'download_8.jpg', '2024-05-02 06:55:01', '2024-05-02 06:55:01'),
(9, 'download_9.jpg', '2024-05-02 06:55:01', '2024-05-02 06:55:01'),
(10, 'download_10.jpg', '2024-05-02 06:55:01', '2024-05-02 06:55:01');

-- --------------------------------------------------------

--
-- Table structure for table `migrations`
--

CREATE TABLE `migrations` (
  `id` int UNSIGNED NOT NULL,
  `migration` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `migrations`
--

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(1, '2014_10_12_000000_create_users_table', 1),
(2, '2014_10_12_100000_create_password_reset_tokens_table', 1),
(3, '2014_10_12_100000_create_password_resets_table', 1),
(4, '2019_08_19_000000_create_failed_jobs_table', 1),
(5, '2019_12_14_000001_create_personal_access_tokens_table', 1),
(6, '2023_06_24_131141_create_settings_table', 1),
(7, '2023_06_24_154209_create_notifications_table', 1),
(8, '2023_12_13_133429_create_otps_table', 1),
(9, '2023_12_13_134202_create_doctors_table', 1),
(10, '2023_12_13_134607_create_appointments_table', 1),
(11, '2023_12_13_134804_create_payments_table', 1),
(12, '2023_12_13_140808_create_splashes_table', 1),
(13, '2023_12_16_170408_create_notes_table', 1),
(14, '2023_12_20_202940_create_advice_table', 1),
(15, '2023_12_20_204122_create_sections_table', 1),
(16, '2023_12_22_185908_create_questions_table', 1),
(17, '2023_12_22_190850_create_user_questions_table', 1),
(18, '2024_01_04_094653_create_static_pages_table', 1),
(19, '2024_01_30_151526_create_feedback_table', 1),
(20, '2024_04_07_194100_create_games_table', 1),
(21, '2024_05_04_174112_create_chats_table', 2),
(22, '2024_05_04_174120_create_chat_messages_table', 2),
(23, '2024_05_14_094721_create_virtual_activities_table', 3),
(24, '2024_06_24_042944_create_score_records_table', 4);

-- --------------------------------------------------------

--
-- Table structure for table `notes`
--

CREATE TABLE `notes` (
  `id` bigint UNSIGNED NOT NULL,
  `user_id` bigint UNSIGNED NOT NULL,
  `date` date NOT NULL,
  `title` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `keyword` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `details` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `status` tinyint(1) NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `notifications`
--

CREATE TABLE `notifications` (
  `id` char(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `type` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `notifiable_type` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `notifiable_id` bigint UNSIGNED NOT NULL,
  `data` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `read_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `otps`
--

CREATE TABLE `otps` (
  `id` bigint UNSIGNED NOT NULL,
  `user_id` bigint UNSIGNED NOT NULL,
  `code` int NOT NULL,
  `expire` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `otps`
--

INSERT INTO `otps` (`id`, `user_id`, `code`, `expire`, `created_at`, `updated_at`) VALUES
(1, 1, 1111, '2024-05-02 06:55:00', '2024-05-02 06:55:00', '2024-05-02 06:55:00'),
(2, 2, 1111, '2023-12-14 20:02:03', '2023-12-14 20:02:03', '2023-12-14 20:02:03'),
(3, 3, 1111, '2023-12-14 20:29:02', '2023-12-14 20:29:02', '2023-12-14 20:29:02'),
(4, 4, 1111, '2023-12-15 09:16:47', '2023-12-14 21:04:47', '2023-12-14 21:04:47'),
(5, 5, 1111, '2024-05-04 02:44:20', '2024-05-04 02:44:20', '2024-05-04 02:44:20');

-- --------------------------------------------------------

--
-- Table structure for table `password_resets`
--

CREATE TABLE `password_resets` (
  `email` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `password_reset_tokens`
--

CREATE TABLE `password_reset_tokens` (
  `email` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `payments`
--

CREATE TABLE `payments` (
  `id` bigint UNSIGNED NOT NULL,
  `user_id` bigint UNSIGNED NOT NULL,
  `appointment_id` bigint UNSIGNED NOT NULL,
  `amount` double NOT NULL,
  `card_name` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `card_number` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `expire_date` date NOT NULL,
  `cvv` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `personal_access_tokens`
--

CREATE TABLE `personal_access_tokens` (
  `id` bigint UNSIGNED NOT NULL,
  `tokenable_type` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `tokenable_id` bigint UNSIGNED NOT NULL,
  `name` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `abilities` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `last_used_at` timestamp NULL DEFAULT NULL,
  `expires_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `personal_access_tokens`
--

INSERT INTO `personal_access_tokens` (`id`, `tokenable_type`, `tokenable_id`, `name`, `token`, `abilities`, `last_used_at`, `expires_at`, `created_at`, `updated_at`) VALUES
(1, 'App\\Models\\User', 5, 'AuthToken', '2adb266d299602f5942354b4d03d9c490d30fb9d636abade86fd5cd04465e904', '[\"*\"]', NULL, NULL, '2024-05-04 02:44:54', '2024-05-04 02:44:54'),
(2, 'App\\Models\\User', 5, 'AuthToken', '22209ba844ca92d9418833d5238d0c37692a2d4653703fc1f6feb738fe5374a4', '[\"*\"]', '2024-05-04 05:18:50', NULL, '2024-05-04 02:45:49', '2024-05-04 05:18:50'),
(3, 'App\\Models\\User', 5, 'AuthToken', 'd129de8dec904af986d0b7fe8b6732fd9499a86703f77a32bd7384d474ebc915', '[\"*\"]', '2024-06-24 01:52:41', NULL, '2024-05-14 06:25:48', '2024-06-24 01:52:41');

-- --------------------------------------------------------

--
-- Table structure for table `questions`
--

CREATE TABLE `questions` (
  `id` bigint UNSIGNED NOT NULL,
  `question` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `answers` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `correct` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `questions`
--

INSERT INTO `questions` (`id`, `question`, `answers`, `correct`, `created_at`, `updated_at`) VALUES
(1, 'Lorem ipsum dolor sit amet?', 'never,always,sometimes,usually', 'never', '2023-12-18 20:35:58', '2023-12-18 20:35:58'),
(2, 'Lorem ipsum dolor sit amet?', 'never,always,sometimes,usually', 'always', '2023-12-18 20:35:58', '2023-12-18 20:35:58'),
(3, 'Lorem ipsum dolor sit amet?', 'never,always,sometimes,usually', 'sometimes', '2023-12-18 20:35:58', '2023-12-18 20:35:58'),
(4, 'Lorem ipsum dolor sit amet?', 'never,always,sometimes,usually', 'usually', '2023-12-18 20:35:58', '2023-12-18 20:35:58'),
(5, 'Lorem ipsum dolor sit amet?', 'never,always,sometimes,usually', 'usually', '2023-12-18 20:35:58', '2023-12-18 20:35:58'),
(6, 'Lorem ipsum dolor sit amet?', 'never,always,sometimes,usually', 'sometimes', '2023-12-18 20:35:58', '2023-12-18 20:35:58'),
(7, 'Lorem ipsum dolor sit amet?', 'never,always,sometimes,usually', 'sometimes', '2023-12-18 20:35:58', '2023-12-18 20:35:58'),
(8, 'Lorem ipsum dolor sit amet?', 'never,always,sometimes,usually', 'always', '2023-12-18 20:35:58', '2023-12-18 20:35:58'),
(9, 'Lorem ipsum dolor sit amet?', 'never,always,sometimes,usually', 'never', '2023-12-18 20:35:58', '2023-12-18 20:35:58');

-- --------------------------------------------------------

--
-- Table structure for table `score_records`
--

CREATE TABLE `score_records` (
  `id` bigint UNSIGNED NOT NULL,
  `user_id` bigint UNSIGNED DEFAULT NULL,
  `saturday_score` decimal(8,2) NOT NULL DEFAULT '0.00',
  `sunday_score` decimal(8,2) NOT NULL DEFAULT '0.00',
  `monday_score` decimal(8,2) NOT NULL DEFAULT '0.00',
  `tuesday_score` decimal(8,2) NOT NULL DEFAULT '0.00',
  `wednesday_score` decimal(8,2) NOT NULL DEFAULT '0.00',
  `thursday_score` decimal(8,2) NOT NULL DEFAULT '0.00',
  `friday_score` decimal(8,2) NOT NULL DEFAULT '0.00',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `score_records`
--

INSERT INTO `score_records` (`id`, `user_id`, `saturday_score`, `sunday_score`, `monday_score`, `tuesday_score`, `wednesday_score`, `thursday_score`, `friday_score`, `created_at`, `updated_at`) VALUES
(2, 5, 25.50, 0.00, 0.00, 100.00, 0.00, 0.00, 0.00, '2024-06-24 01:49:59', '2024-06-24 01:50:26');

-- --------------------------------------------------------

--
-- Table structure for table `sections`
--

CREATE TABLE `sections` (
  `id` bigint UNSIGNED NOT NULL,
  `title` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `subtitle` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `image` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `sections`
--

INSERT INTO `sections` (`id`, `title`, `subtitle`, `image`, `created_at`, `updated_at`) VALUES
(1, 'Not Sure Its ADHD?', 'Complete Free Assessment', 'test.png', '2023-12-18 20:35:58', '2023-12-18 20:35:58'),
(2, 'Do You Want Some Advice ADHD?', 'Take Some Advice', 'advice.png', '2023-12-18 20:35:58', '2023-12-18 20:35:58'),
(3, 'Not To Mother', 'Follow Up With Dr', 'notes.png', '2023-12-18 20:35:58', '2023-12-18 20:35:58');

-- --------------------------------------------------------

--
-- Table structure for table `settings`
--

CREATE TABLE `settings` (
  `id` bigint UNSIGNED NOT NULL,
  `key` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `value` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `type` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `label` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `settings`
--

INSERT INTO `settings` (`id`, `key`, `value`, `type`, `label`, `created_at`, `updated_at`) VALUES
(1, 'logo_app', 'logo.jpg', 'App', 'logo', '2023-12-18 20:35:58', '2023-12-18 20:35:58'),
(2, 'name_app', 'ADHD', 'App', 'name_app', '2023-12-18 20:35:58', '2023-12-18 20:35:58'),
(3, 'logo', 'logo.png', 'App', 'logo_app', '2023-12-18 20:35:58', '2023-12-18 20:35:58'),
(4, 'home', 'home.jpg', 'Home', 'image', '2023-12-18 20:35:58', '2023-12-18 20:35:58'),
(5, 'Depression', 'Depression test', 'Others', 'Your daily mental health coach', '2023-12-18 20:35:58', '2023-12-18 20:35:58'),
(6, 'anxiety', 'anxiety test', 'Others', 'Your daily mental health coach', '2023-12-18 20:35:58', '2023-12-18 20:35:58'),
(7, 'bipolar', 'bipolar test', 'Others', 'Your daily mental health coach', '2023-12-18 20:35:58', '2023-12-18 20:35:58'),
(8, 'PTSD', 'PTSD Test', 'Others', 'Your daily mental health coach', '2023-12-18 20:35:58', '2023-12-18 20:35:58');

-- --------------------------------------------------------

--
-- Table structure for table `splashes`
--

CREATE TABLE `splashes` (
  `id` bigint UNSIGNED NOT NULL,
  `image` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `title` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `body` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `splashes`
--

INSERT INTO `splashes` (`id`, `image`, `title`, `body`, `created_at`, `updated_at`) VALUES
(1, 'splashes_page1.png', 'page1', 'splash_page splash_page splash_page', NULL, NULL),
(2, 'splashes_page2.png', 'page2', 'splash_page splash_page splash_page', NULL, NULL),
(3, 'splashes_page3.png', 'page3', 'splash_page splash_page splash_page', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `static_pages`
--

CREATE TABLE `static_pages` (
  `id` bigint UNSIGNED NOT NULL,
  `title` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `details` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `image` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `static_pages`
--

INSERT INTO `static_pages` (`id`, `title`, `details`, `image`, `created_at`, `updated_at`) VALUES
(1, 'help', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit ut aliquamLorem ipsum dolor sit amet,consectetur adipiscing elit ut aliquam.?..', 'help.jpg', '2023-12-18 20:35:58', '2023-12-18 20:35:58'),
(2, 'terms and privacy', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit ut aliquamLorem ipsum dolor sit amet,consectetur adipiscing elit ut aliquam.?..', 'privacy.jpg', '2023-12-18 20:35:58', '2023-12-18 20:35:58');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` bigint UNSIGNED NOT NULL,
  `first_name` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `last_name` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `Id_number` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `user_type` enum('admin','patient','doctor') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'patient',
  `email` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `phone` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `image` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `certificate` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `notification_status` tinyint(1) NOT NULL DEFAULT '0',
  `remember_token` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `first_name`, `last_name`, `Id_number`, `user_type`, `email`, `email_verified_at`, `password`, `phone`, `image`, `certificate`, `notification_status`, `remember_token`, `created_at`, `updated_at`) VALUES
(1, 'mohamed', 'elmeleeh', '1234567891234', 'admin', 'mohamed@gmail.com', NULL, '$2y$10$TwtJnAfNXCyCyEiN5ONj2.r8INaOfbkBozguR1C3vVUecPeHULA7m', '0123456789', NULL, NULL, 1, NULL, '2024-05-02 06:55:00', '2024-05-02 06:55:00'),
(2, 'mostafa', 'ahmed', '12345678912378', 'patient', 'patient@app.com', '2024-05-04 02:44:37', '$2y$10$AavbggbhjPYyERPeCTDmJuOp2xDkofgB69ho2xHympJcecLg9WUJS', '01247852368', 'patient.png', NULL, 0, NULL, '2023-12-14 20:02:03', '2023-12-14 20:02:03'),
(3, 'ahmed', 'mahmoud', '12345678912345', 'patient', 'ahmed@gmail.com', NULL, '$2y$10$yCkW5FOtWwj3/0NAM5ZVgOxOAswncZA6zGqMPG9h.DaqnOhIzOBZe', '01054785236', 'doctor.jpg', NULL, 0, NULL, '2023-12-14 20:29:02', '2023-12-14 20:29:02'),
(4, 'mahmoud', 'ahmed', '12345678912344', 'patient', 'mahmoud@gmail.com', NULL, '$2y$10$fk2/txoWQbTGRNndn/uZ3ebclpb4P/jhUz1eVkgfsDbo5vb4N0Dwi', '01054785234', 'doctor_2.jpg', NULL, 0, NULL, '2023-12-14 21:04:47', '2023-12-14 21:04:47'),
(5, 'sultan', 'ahmed', '12345678912211', 'patient', 'sultan@app.com', '2024-05-04 02:44:37', '$2y$10$PC5HpEnC0jmzb.gvdUPduuf7NUoGgfoJeqDOfppPBWze/P56s5tPy', '01555721816', NULL, NULL, 0, NULL, '2024-05-04 02:44:20', '2024-05-04 02:44:37');

-- --------------------------------------------------------

--
-- Table structure for table `user_questions`
--

CREATE TABLE `user_questions` (
  `id` bigint UNSIGNED NOT NULL,
  `user_id` bigint UNSIGNED NOT NULL,
  `question_id` bigint UNSIGNED NOT NULL,
  `status_answer` tinyint NOT NULL,
  `status` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'complete',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `virtual_activities`
--

CREATE TABLE `virtual_activities` (
  `id` bigint UNSIGNED NOT NULL,
  `user_id` bigint UNSIGNED DEFAULT NULL,
  `game_id` int UNSIGNED DEFAULT NULL,
  `if_level_open` tinyint(1) NOT NULL DEFAULT '0',
  `score` int UNSIGNED NOT NULL DEFAULT '0',
  `rate` int UNSIGNED NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `virtual_activities`
--

INSERT INTO `virtual_activities` (`id`, `user_id`, `game_id`, `if_level_open`, `score`, `rate`, `created_at`, `updated_at`) VALUES
(10, 5, 1, 1, 95, 4, '2024-06-01 00:20:57', '2024-06-01 00:32:44'),
(13, 5, 2, 0, 0, 0, '2024-06-01 00:26:57', '2024-06-01 00:26:57'),
(14, 5, 3, 0, 0, 0, '2024-06-01 00:26:57', '2024-06-01 00:26:57'),
(15, 5, 2, 1, 0, 0, '2024-06-01 00:32:44', '2024-06-01 00:32:44');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `advice`
--
ALTER TABLE `advice`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `appointments`
--
ALTER TABLE `appointments`
  ADD PRIMARY KEY (`id`),
  ADD KEY `appointments_doctor_id_foreign` (`doctor_id`),
  ADD KEY `appointments_patient_id_index` (`patient_id`);

--
-- Indexes for table `chats`
--
ALTER TABLE `chats`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `chat_messages`
--
ALTER TABLE `chat_messages`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `doctors`
--
ALTER TABLE `doctors`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `failed_jobs`
--
ALTER TABLE `failed_jobs`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `failed_jobs_uuid_unique` (`uuid`);

--
-- Indexes for table `feedback`
--
ALTER TABLE `feedback`
  ADD PRIMARY KEY (`id`),
  ADD KEY `feedback_user_id_foreign` (`user_id`);

--
-- Indexes for table `games`
--
ALTER TABLE `games`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `migrations`
--
ALTER TABLE `migrations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `notes`
--
ALTER TABLE `notes`
  ADD PRIMARY KEY (`id`),
  ADD KEY `notes_user_id_foreign` (`user_id`);

--
-- Indexes for table `notifications`
--
ALTER TABLE `notifications`
  ADD PRIMARY KEY (`id`),
  ADD KEY `notifications_notifiable_type_notifiable_id_index` (`notifiable_type`,`notifiable_id`);

--
-- Indexes for table `otps`
--
ALTER TABLE `otps`
  ADD PRIMARY KEY (`id`),
  ADD KEY `otps_user_id_foreign` (`user_id`);

--
-- Indexes for table `password_resets`
--
ALTER TABLE `password_resets`
  ADD KEY `password_resets_email_index` (`email`);

--
-- Indexes for table `password_reset_tokens`
--
ALTER TABLE `password_reset_tokens`
  ADD PRIMARY KEY (`email`);

--
-- Indexes for table `payments`
--
ALTER TABLE `payments`
  ADD PRIMARY KEY (`id`),
  ADD KEY `payments_user_id_foreign` (`user_id`),
  ADD KEY `payments_appointment_id_foreign` (`appointment_id`);

--
-- Indexes for table `personal_access_tokens`
--
ALTER TABLE `personal_access_tokens`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `personal_access_tokens_token_unique` (`token`),
  ADD KEY `personal_access_tokens_tokenable_type_tokenable_id_index` (`tokenable_type`,`tokenable_id`);

--
-- Indexes for table `questions`
--
ALTER TABLE `questions`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `score_records`
--
ALTER TABLE `score_records`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `sections`
--
ALTER TABLE `sections`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `settings`
--
ALTER TABLE `settings`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `splashes`
--
ALTER TABLE `splashes`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `static_pages`
--
ALTER TABLE `static_pages`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `users_email_unique` (`email`);

--
-- Indexes for table `user_questions`
--
ALTER TABLE `user_questions`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_questions_user_id_foreign` (`user_id`),
  ADD KEY `user_questions_question_id_foreign` (`question_id`);

--
-- Indexes for table `virtual_activities`
--
ALTER TABLE `virtual_activities`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `advice`
--
ALTER TABLE `advice`
  MODIFY `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT for table `appointments`
--
ALTER TABLE `appointments`
  MODIFY `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `chats`
--
ALTER TABLE `chats`
  MODIFY `id` int UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `chat_messages`
--
ALTER TABLE `chat_messages`
  MODIFY `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `doctors`
--
ALTER TABLE `doctors`
  MODIFY `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `failed_jobs`
--
ALTER TABLE `failed_jobs`
  MODIFY `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `feedback`
--
ALTER TABLE `feedback`
  MODIFY `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `games`
--
ALTER TABLE `games`
  MODIFY `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `migrations`
--
ALTER TABLE `migrations`
  MODIFY `id` int UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=25;

--
-- AUTO_INCREMENT for table `notes`
--
ALTER TABLE `notes`
  MODIFY `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `otps`
--
ALTER TABLE `otps`
  MODIFY `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `payments`
--
ALTER TABLE `payments`
  MODIFY `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `personal_access_tokens`
--
ALTER TABLE `personal_access_tokens`
  MODIFY `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `questions`
--
ALTER TABLE `questions`
  MODIFY `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `score_records`
--
ALTER TABLE `score_records`
  MODIFY `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `sections`
--
ALTER TABLE `sections`
  MODIFY `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `settings`
--
ALTER TABLE `settings`
  MODIFY `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `splashes`
--
ALTER TABLE `splashes`
  MODIFY `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `static_pages`
--
ALTER TABLE `static_pages`
  MODIFY `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `user_questions`
--
ALTER TABLE `user_questions`
  MODIFY `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `virtual_activities`
--
ALTER TABLE `virtual_activities`
  MODIFY `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `appointments`
--
ALTER TABLE `appointments`
  ADD CONSTRAINT `appointments_doctor_id_foreign` FOREIGN KEY (`doctor_id`) REFERENCES `doctors` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `appointments_patient_id_foreign` FOREIGN KEY (`patient_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `feedback`
--
ALTER TABLE `feedback`
  ADD CONSTRAINT `feedback_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `notes`
--
ALTER TABLE `notes`
  ADD CONSTRAINT `notes_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `otps`
--
ALTER TABLE `otps`
  ADD CONSTRAINT `otps_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `payments`
--
ALTER TABLE `payments`
  ADD CONSTRAINT `payments_appointment_id_foreign` FOREIGN KEY (`appointment_id`) REFERENCES `appointments` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `payments_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `user_questions`
--
ALTER TABLE `user_questions`
  ADD CONSTRAINT `user_questions_question_id_foreign` FOREIGN KEY (`question_id`) REFERENCES `questions` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `user_questions_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
